import pandas as pd
import streamlit as st
from st_aggrid import AgGrid, GridOptionsBuilder, JsCode, GridUpdateMode, DataReturnMode

from models.enums import AllocationState


def render_allocation_matrix():
    """Render the allocation matrix UI.

    Single AG Grid matrix with inline cell editing and per-cell colours.
    Clicking any cell auto-detects both destination (row) and transporter (column).
    Lock / Block / Release buttons appear below once a cell is selected.
    """
    allocation = st.session_state.allocation
    supply = st.session_state.supply
    demand = st.session_state.demand

    if not allocation or not supply or not demand:
        st.info("No allocation data available yet.")
        return

    destinations = sorted(demand.keys())
    transporters = sorted(supply.keys())

    # ── Build DataFrame for AG Grid ───────────────────────────────────────────
    df_data: dict = {"Destination": destinations}
    for tpt in transporters:
        df_data[tpt] = [allocation[city][tpt]["value"] for city in destinations]
        df_data[f"state_{tpt}"] = [
            allocation[city][tpt]["state"].name for city in destinations
        ]
    # Hidden column used to communicate clicked column back to Python
    df_data["_sel_col"] = [""] * len(destinations)
    df = pd.DataFrame(df_data)

    # ── JS: per-cell colour ───────────────────────────────────────────────────
    cell_style_js = JsCode("""
    function(params) {
        const stateField = 'state_' + params.colDef.field;
        const state = params.data[stateField];
        if (state === 'LOCKED')   return {backgroundColor: '#FFF2CC', color: '#8B6914'};
        if (state === 'BLOCKED')  return {backgroundColor: '#FFCCCC', color: '#8B0000'};
        if (state === 'DISABLED') return {backgroundColor: '#EEEEEE', color: '#888888'};
        return {backgroundColor: '#C6EFCE', color: '#276221'};
    }
    """)

    # ── JS: editability ───────────────────────────────────────────────────────
    editable_js = JsCode("""
    function(params) {
        const stateField = 'state_' + params.colDef.field;
        const state = params.data[stateField];
        return state !== 'DISABLED' && state !== 'BLOCKED';
    }
    """)

    # ── JS: cell click → write column name to hidden _sel_col ────────────────
    cell_clicked_js = JsCode("""
    function(params) {
        var field = params.colDef.field;
        if (!field || field === 'Destination' || field.startsWith('state_') || field === '_sel_col') return;
        var updated = Object.assign({}, params.data);
        updated['_sel_col'] = field;
        params.api.applyTransaction({update: [updated]});
    }
    """)

    # ── AG Grid configuration ─────────────────────────────────────────────────
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(editable=False, resizable=True, sortable=False)
    gb.configure_column("Destination", pinned="left", editable=False, width=160)

    for tpt in transporters:
        gb.configure_column(
            tpt,
            editable=editable_js,
            type=["numericColumn"],
            cellStyle=cell_style_js,
            width=130,
        )
        gb.configure_column(f"state_{tpt}", hide=True)

    gb.configure_column("_sel_col", hide=True)
    gb.configure_selection(selection_mode="single", use_checkbox=False)
    gb.configure_grid_options(onCellClicked=cell_clicked_js)

    # Dynamic key: changes whenever any route state changes, forcing AG Grid to
    # re-initialise with fresh data so cell colours always reflect current state.
    state_hash = hash(tuple(
        allocation[city][tpt]["state"].name
        for city in sorted(allocation.keys())
        for tpt in sorted(supply.keys())
    )) % 100000
    grid_key = f"alloc_matrix_{state_hash}"

    st.markdown("#### Allocation Matrix")
    st.caption(
        "🟢 Released \u00a0 🟠 Locked \u00a0 🔴 Blocked \u00a0 ⬜ Disabled \u00a0|\u00a0 "
        "Click a cell to select a route, then use Lock / Block / Release below."
    )

    grid_return = AgGrid(
        df,
        gridOptions=gb.build(),
        update_mode=GridUpdateMode.VALUE_CHANGED | GridUpdateMode.SELECTION_CHANGED,
        data_return_mode=DataReturnMode.AS_INPUT,
        allow_unsafe_jscode=True,
        use_container_width=True,
        height=min(450, 80 + len(destinations) * 40),
        key=grid_key,
    )

    # ── Detect value changes and cell clicks ──────────────────────────────────
    returned_df = grid_return["data"]
    value_changed = False
    if returned_df is not None and not returned_df.empty:
        for _, row in returned_df.iterrows():
            city = row["Destination"]
            if city not in allocation:
                continue

            # Auto-detect cell click from _sel_col
            sel_col_val = row.get("_sel_col", "")
            if sel_col_val and sel_col_val in transporters:
                st.session_state["sel_dest"] = city
                st.session_state["sel_tpt"] = sel_col_val

            # Detect numeric value edits
            for tpt in transporters:
                try:
                    new_val = int(row[tpt]) if pd.notna(row[tpt]) else 0
                except (ValueError, TypeError):
                    new_val = 0
                old_val = allocation[city][tpt]["value"]
                state = allocation[city][tpt]["state"]
                if (
                    new_val != old_val
                    and state not in (AllocationState.DISABLED, AllocationState.BLOCKED)
                ):
                    allocation[city][tpt]["value"] = new_val
                    allocation[city][tpt]["state"] = AllocationState.LOCKED
                    value_changed = True
                    st.session_state["sel_dest"] = city
                    st.session_state["sel_tpt"] = tpt

    if value_changed:
        st.session_state.allocation_changed = True
        st.rerun()

    # ── Route state controls ──────────────────────────────────────────────────
    sel_dest = st.session_state.get("sel_dest")
    sel_tpt = st.session_state.get("sel_tpt")

    st.markdown("#### Route Control")

    # Lock / Block / Release buttons
    current_state = None
    btn_disabled = True
    if (
        sel_dest
        and sel_tpt
        and sel_dest in allocation
        and sel_tpt in allocation.get(sel_dest, {})
    ):
        current_state = allocation[sel_dest][sel_tpt]["state"]
        btn_disabled = current_state == AllocationState.DISABLED

    col_lock, col_block, col_rel = st.columns(3)
    with col_lock:
        lock_clicked = st.button(
            "Lock", key="btn_lock", disabled=btn_disabled, use_container_width=True
        )
    with col_block:
        block_clicked = st.button(
            "Block", key="btn_blk", disabled=btn_disabled, use_container_width=True
        )
    with col_rel:
        rel_clicked = st.button(
            "Release", key="btn_rel", disabled=btn_disabled, use_container_width=True
        )

    if current_state is not None and sel_dest and sel_tpt:
        status_str = "DISABLED (no route)" if current_state == AllocationState.DISABLED else current_state.name
        st.caption(f"Selected: **{sel_dest} \u2192 {sel_tpt}** \u00a0|\u00a0 State: **{status_str}**")
    else:
        st.caption("Click any cell in the matrix above to select a route.")

    if lock_clicked:
        st.session_state.allocation[sel_dest][sel_tpt]["state"] = AllocationState.LOCKED
        st.session_state.allocation_changed = True
        st.rerun()

    if block_clicked:
        st.session_state.allocation[sel_dest][sel_tpt]["state"] = AllocationState.BLOCKED
        st.session_state.allocation[sel_dest][sel_tpt]["value"] = 0
        st.session_state.allocation_changed = True
        st.rerun()

    if rel_clicked:
        st.session_state.allocation[sel_dest][sel_tpt]["state"] = AllocationState.RELEASE
        st.session_state.allocation_changed = True
        st.rerun()
