import pandas as pd
import streamlit as st

from services.data_loader import load_cost_file, load_demand_file, load_supply_file
from ui.state import build_initial_allocation

REGION_OPTIONS = ["All", "North", "South", "East", "West", "Central"]


def render_setup_page():
    st.title("Transport Allocator")
    st.markdown("---")

    _render_file_upload_section()

    if not st.session_state.transporters and not st.session_state.destinations:
        st.info("Upload files and click **Load Files** to get started.")
        return

    st.markdown("---")
    _render_region_filter()

    col_dest, col_tpt = st.columns(2)
    with col_dest:
        _render_destination_section()
    with col_tpt:
        _render_transporter_section()

    st.markdown("---")
    _render_allocate_button()


# ── File upload section ────────────────────────────────────────────────────────

def _render_file_upload_section():
    st.subheader("Data Files")
    col1, col2, col3 = st.columns(3)

    with col1:
        cost_file = st.file_uploader(
            "Cost (.xlsx)",
            type=["xlsx"],
            key="cost_file_uploader",
            help="Required first. Columns: Transporter, Destination, Region, Car",
        )
        if cost_file is not None:
            st.session_state.cost_file_bytes_staged = cost_file.read()

    with col2:
        demand_disabled = st.session_state.cost_file_bytes_staged is None
        demand_file = st.file_uploader(
            "Demand (.xlsx)",
            type=["xlsx"],
            key="demand_file_uploader",
            disabled=demand_disabled,
            help="Upload the Cost file first." if demand_disabled else "Columns: Destination, Demand",
        )
        if demand_file is not None:
            st.session_state.demand_file_bytes_staged = demand_file.read()

    with col3:
        supply_disabled = st.session_state.cost_file_bytes_staged is None
        supply_file = st.file_uploader(
            "Supply (.xlsx)",
            type=["xlsx"],
            key="supply_file_uploader",
            disabled=supply_disabled,
            help="Upload the Cost file first." if supply_disabled else "Columns: Transporter, North, South, East, West, Central",
        )
        if supply_file is not None:
            st.session_state.supply_file_bytes_staged = supply_file.read()

    # Load Files button — active when at least the Cost file is staged
    load_ready = st.session_state.cost_file_bytes_staged is not None
    if st.button(
        "Load Files",
        disabled=not load_ready,
        type="primary" if load_ready else "secondary",
    ):
        _process_staged_files()


def _process_staged_files():
    """Process all staged file bytes and populate session state."""
    cost_bytes = st.session_state.cost_file_bytes_staged
    demand_bytes = st.session_state.demand_file_bytes_staged
    supply_bytes = st.session_state.supply_file_bytes_staged

    # --- Cost file (always required) ---
    with st.spinner("Loading cost file..."):
        try:
            transporters, destinations, region_map, cost_matrix, destination_region = (
                load_cost_file(cost_bytes)
            )
            st.session_state.transporters = transporters
            st.session_state.destinations = destinations
            st.session_state.region_map = region_map
            st.session_state.cost_matrix = cost_matrix
            st.session_state.destination_region = destination_region
            st.session_state.cost_file_bytes = cost_bytes
            # Reset all dependent state
            st.session_state.supply = {}
            st.session_state.demand = {}
            st.session_state.min_load = {}
            st.session_state.regional_supply = {}
            st.session_state.supply_df = None
            st.session_state.demand_df = None
            # Clear widget state so multiselects start fresh
            st.session_state["dest_multiselect"] = []
            st.session_state["tpt_multiselect"] = []
        except Exception as e:
            st.error(f"Failed to load Cost file: {e}")
            return

    dest_names = [d.value for d in st.session_state.destinations]
    tpt_names = [t.value for t in st.session_state.transporters]

    # --- Demand file (optional) ---
    if demand_bytes:
        with st.spinner("Loading demand data..."):
            try:
                demand = load_demand_file(demand_bytes, st.session_state.destinations)
                st.session_state.demand = demand
                st.session_state.demand_file_bytes = demand_bytes
                # Build stable demand DataFrame
                st.session_state.demand_df = pd.DataFrame(
                    {"Demand": [demand.get(d, 0) for d in dest_names]},
                    index=dest_names,
                )
                # Pre-select all destinations
                st.session_state["dest_multiselect"] = dest_names
            except Exception as e:
                st.error(f"Failed to load Demand file: {e}")

    # --- Supply file (optional) ---
    if supply_bytes:
        with st.spinner("Loading supply data..."):
            try:
                supply_total, min_load, regional_supply = load_supply_file(
                    supply_bytes, st.session_state.transporters
                )
                st.session_state.supply = supply_total
                st.session_state.min_load = min_load
                st.session_state.regional_supply = regional_supply
                st.session_state.supply_file_bytes = supply_bytes
                # Build stable supply DataFrame (Min Load starts at 0)
                st.session_state.supply_df = pd.DataFrame(
                    {
                        "Supply": [supply_total.get(t, 0) for t in tpt_names],
                        "Min Load": [0] * len(tpt_names),
                    },
                    index=tpt_names,
                )
                # Pre-select all transporters
                st.session_state["tpt_multiselect"] = tpt_names
            except Exception as e:
                st.error(f"Failed to load Supply file: {e}")

    st.success("Files loaded successfully.")


# ── Region filter ──────────────────────────────────────────────────────────────

def _render_region_filter():
    region_filter = st.selectbox(
        "Region Filter",
        options=REGION_OPTIONS,
        index=REGION_OPTIONS.index(st.session_state.region_filter),
        key="region_filter_select",
    )
    st.session_state.region_filter = region_filter


def _available_destinations() -> list[str]:
    region = st.session_state.region_filter
    all_dests = [d.value for d in st.session_state.destinations]
    if region == "All":
        return all_dests
    region_map = st.session_state.region_map
    filtered = set()
    for reg_key, reg_data in region_map.items():
        if reg_key.title() == region:
            filtered.update(reg_data.get("destination", set()))
    return [d for d in all_dests if d in filtered]


def _available_transporters() -> list[str]:
    region = st.session_state.region_filter
    all_tpts = [t.value for t in st.session_state.transporters]
    if region == "All":
        return all_tpts
    region_map = st.session_state.region_map
    filtered = set()
    for reg_key, reg_data in region_map.items():
        if reg_key.title() == region:
            filtered.update(reg_data.get("transporter", set()))
    return [t for t in all_tpts if t in filtered]


# ── Destination section ────────────────────────────────────────────────────────

def _render_destination_section():
    st.subheader("Destinations")
    available = _available_destinations()

    col_sel, col_clear = st.columns([1, 1])
    with col_sel:
        if st.button("Select All", key="dest_select_all", use_container_width=True):
            st.session_state["dest_multiselect"] = available
    with col_clear:
        if st.button("Clear", key="dest_clear", use_container_width=True):
            st.session_state["dest_multiselect"] = []

    selected = st.multiselect(
        "Select Destinations",
        options=available,
        key="dest_multiselect",
    )

    if not selected:
        return

    # Read-only demand table
    demand_df = st.session_state.demand_df
    if demand_df is not None:
        visible_idx = [d for d in selected if d in demand_df.index]
        if visible_idx:
            st.caption("Demand (from Demand file — read only)")
            st.dataframe(demand_df.loc[visible_idx], use_container_width=True)
            total_demand = int(demand_df.loc[visible_idx, "Demand"].sum())
        else:
            total_demand = 0
    else:
        total_demand = sum(st.session_state.demand.get(d, 0) for d in selected)

    st.metric("Total Demand", f"{total_demand:,}")


# ── Transporter section ────────────────────────────────────────────────────────

def _render_transporter_section():
    st.subheader("Transporters")
    available = _available_transporters()

    col_sel, col_clear = st.columns([1, 1])
    with col_sel:
        if st.button("Select All", key="tpt_select_all", use_container_width=True):
            st.session_state["tpt_multiselect"] = available
    with col_clear:
        if st.button("Clear", key="tpt_clear", use_container_width=True):
            st.session_state["tpt_multiselect"] = []

    selected = st.multiselect(
        "Select Transporters",
        options=available,
        key="tpt_multiselect",
    )

    if not selected:
        return

    supply_df = st.session_state.supply_df
    if supply_df is not None:
        st.caption("Supply (read only) · Min Load (editable — shows all loaded transporters)")
        # Pass the FULL stable DataFrame — never copy or filter here.
        # Filtering by selection would shift positional row indices and break data_editor state.
        edited = st.data_editor(
            supply_df,
            use_container_width=True,
            key="supply_editor",
            column_config={
                "Supply": st.column_config.NumberColumn("Supply", disabled=True),
                "Min Load": st.column_config.NumberColumn("Min Load", min_value=0, step=1),
            },
        )

        # Validate — DO NOT write back to supply_df (that would destabilise the base df)
        invalid = [t for t in edited.index if edited.loc[t, "Min Load"] > edited.loc[t, "Supply"]]
        if invalid:
            st.error(
                f"Min Load exceeds Supply for: {', '.join(invalid)}. Fix before allocating."
            )

        # Store current Min Load values for the Allocate button
        st.session_state.min_load = {t: int(edited.loc[t, "Min Load"]) for t in edited.index}

        total_supply = int(supply_df.loc[supply_df.index.isin(selected), "Supply"].sum())
    else:
        total_supply = sum(st.session_state.supply.get(t, 0) for t in selected)

    selected_dest = st.session_state.get("dest_multiselect", [])
    demand_df = st.session_state.demand_df
    if demand_df is not None:
        visible_dests = [d for d in selected_dest if d in demand_df.index]
        total_demand = int(demand_df.loc[visible_dests, "Demand"].sum()) if visible_dests else 0
    else:
        total_demand = sum(st.session_state.demand.get(d, 0) for d in selected_dest)

    balance = total_supply - total_demand
    col_s, col_b = st.columns(2)
    with col_s:
        st.metric("Total Supply", f"{total_supply:,}")
    with col_b:
        st.metric(
            "Balance (Supply - Demand)",
            f"{balance:+,}",
            delta_color="off" if balance == 0 else ("normal" if balance > 0 else "inverse"),
        )


# ── Allocate button ────────────────────────────────────────────────────────────

def _render_allocate_button():
    selected_dest = st.session_state.get("dest_multiselect", [])
    selected_tpt = st.session_state.get("tpt_multiselect", [])

    ready = bool(selected_dest and selected_tpt)
    if not ready:
        st.warning("Select at least one destination and one transporter to proceed.")

    if st.button("Allocate ->", disabled=not ready, type="primary"):
        supply_df = st.session_state.supply_df
        demand_df = st.session_state.demand_df
        current_min_load = st.session_state.min_load  # updated from data_editor each render

        if supply_df is not None:
            supply = {
                t: int(supply_df.loc[t, "Supply"])
                for t in selected_tpt if t in supply_df.index
            }
            min_load = {
                t: current_min_load.get(t, 0)
                for t in selected_tpt
            }
            # Block allocation if any selected transporter has min_load > supply
            overloaded = [t for t in selected_tpt if min_load.get(t, 0) > supply.get(t, 0)]
            if overloaded:
                st.error(
                    f"Min Load exceeds Supply for: {', '.join(overloaded)}. Fix before allocating."
                )
                return
        else:
            supply = {t: st.session_state.supply.get(t, 0) for t in selected_tpt}
            min_load = {t: st.session_state.min_load.get(t, 0) for t in selected_tpt}

        if demand_df is not None:
            demand = {
                d: int(demand_df.loc[d, "Demand"])
                for d in selected_dest if d in demand_df.index
            }
        else:
            demand = {d: st.session_state.demand.get(d, 0) for d in selected_dest}

        regional_supply = {
            t: st.session_state.regional_supply.get(t, {}) for t in selected_tpt
        }

        if sum(supply.values()) == 0:
            st.error("Total supply is zero. Upload the Supply file and check values.")
            return
        if sum(demand.values()) == 0:
            st.error("Total demand is zero. Upload the Demand file and check values.")
            return

        st.session_state.supply = supply
        st.session_state.demand = demand
        st.session_state.min_load = min_load
        st.session_state.regional_supply = regional_supply
        st.session_state.allocation_history = []
        st.session_state.allocation = build_initial_allocation(
            demand, supply, st.session_state.cost_matrix
        )
        st.session_state.page = "allocation"
        st.rerun()
