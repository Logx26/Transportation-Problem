import streamlit as st

from ui.state import init_session_state
from ui.pages.setup_page import render_setup_page
from ui.pages.allocation_page import render_allocation_page

st.set_page_config(
    page_title="Transport Allocator",
    page_icon="\U0001F69A",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_session_state()

if st.session_state.page == "setup":
    render_setup_page()
else:
    render_allocation_page()
