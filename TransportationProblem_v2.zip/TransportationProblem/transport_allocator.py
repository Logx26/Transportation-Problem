import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from enum import Enum
import re
import os
import pandas as pd
from pulp import *
import openpyxl
from openpyxl.styles import PatternFill
import xlsxwriter
from datetime import datetime
import duckdb
import locale
# import duckdb_spatial

INFINITY = 10**10

class transportAllocator(QWidget):
   def __init__(self, parent = None):
      super(transportAllocator, self).__init__(parent)
      self.costFileName = "Cost File.xlsx"
      self.loadSheetName = ""
      self.entrySheetName = ""
      self.optimalCost=0
      self.labelFont = QFont("Helvetica", 10)
      # self.setStyleSheet("background:white")
      self.setGeometry(0,0,1600,900)
      qtRectangle = self.frameGeometry()
      centerPoint = QDesktopWidget().availableGeometry().center()
      qtRectangle.moveCenter(centerPoint)
      self.move(qtRectangle.topLeft())
      if getattr(sys, 'frozen', False):
         # If the pyinstallerlication is bundled
         self.base_path = sys._MEIPASS
      else:
         # If the application is not bundled
         self.base_path = os.path.abspath(".")

      self.transporter=[]
      self.destination=[Category("Trichy"),Category("Madurai"),Category("Coimbatore"),Category("Chennai"),Category("Pudukottai")]
      self.supply={}
      self.demand={}
      self.region={}
      self.minimumLoad={}
      self.allocationHistory = []
      self.allocationCostHistory = []
      self.masterLayout = QVBoxLayout()
      self.AllocationChanged = False

      self.titleFrame = self.setupTitleLayout()      
      self.bodyFrame = self.setupBodyLayout()
      self.allocationFrame = self.setupAllocationPage()

      # supplyDemandLayout./
      self.masterLayout.addWidget(self.titleFrame)
      self.masterLayout.addWidget(self.bodyFrame)
      self.masterLayout.addWidget(self.allocationFrame)
      # masterLayout.addStretch()

      self.setLayout(self.masterLayout)
      self.setWindowTitle("Transport Allocator")
      print("UI Rendered...")

   def getRupeeFormat(self,amount):
      locale.setlocale(locale.LC_ALL, 'en_IN.UTF-8')
      rupee_format = locale.currency(amount, grouping=True, symbol=False)
      rupee_format = f"₹{rupee_format}"
      return rupee_format
      
   @property
   def AllocationChanged(self):
      return self.allocationChanged

   @AllocationChanged.setter
   def AllocationChanged(self, new_value):
      self.allocationChanged = new_value
      if hasattr(self, 'exportBtn'):
         self.exportBtn.setDisabled(self.allocationChanged)
      if hasattr(self, 'reAllocateBtn'):
         self.reAllocateBtn.setDisabled(not self.allocationChanged)

   @AllocationChanged.deleter
   def AllocationChanged(self):
      del self.allocationChanged
		
   def getCostFile(self):
      fname = QFileDialog.getOpenFileName(self, 'Open Cost file', 
         '.',"xlsx files (*.xlsx)")
      if fname is not None:
         if os.path.exists(fname[0]):
            self.costFileName=fname[0]
            self.getData(self.costFileName)
            self.costFilePath.setText(fname[0])
   
   def getData(self,filename):
      if filename is not None:
         print("Reading Cost file:",self.costFileName)
         duckdb.install_extension('spatial')
         duckdb.load_extension('spatial')
         rows = duckdb.sql(f"""
            select distinct upper(trim(Transporter)), upper(trim(Region))
               FROM st_read('{filename}') 
               order by Transporter
            """)
         transport=[]
         while row := rows.fetchone():
            transport.append(row[0])
            if row[1] not in self.region.keys():
               self.region[row[1]]=dict()
               self.region[row[1]]['transporter']=set(row[0])
            else:
               self.region[row[1]]['transporter'].add(row[0])
         self.transporter=[Category(tpt) for tpt in sorted(set(transport))]
         
         rows = duckdb.sql(f"""
            select distinct upper(trim(Destination)), upper(trim(Region))
               FROM st_read('{filename}') 
               order by Destination
            """)
         destination=[]
         while row := rows.fetchone():
            destination.append(row[0].capitalize())
            if row[1] not in self.region.keys() or 'destination' not in self.region[row[1]].keys():
               self.region[row[1]]['destination']=set(row[0].capitalize())
            else:
               self.region[row[1]]['destination'].add(row[0].capitalize())
            
         self.destination=[Category(city) for city in sorted(set(destination))]
         
         self.setCostMatrix(destination,transport)

   def setCostMatrix(self,destination,transport):
      print("Constructing Cost Matrix...")
      cost_file = duckdb.sql(f"""
         select distinct upper(trim(Destination)) as Destination, upper(trim(Transporter)) as Transporter, "Medium Car / INR"
            FROM st_read('{self.costFileName}') 
            order by Destination, Transporter
         """).df()
      
      cost_file['Destination'] = cost_file['Destination'].str.capitalize()
      cost_matrix = {}
      for tpt in transport:
         cost = dict()
         for city in destination:
            if city == 'zzz_dummy_destination':
               cost[city]=0
            else:
               cost[city]=INFINITY
         cost_matrix[tpt]=cost

      for city, tpt, price in zip(cost_file['Destination'], cost_file['Transporter'], cost_file['Medium Car / INR']):
         if tpt in cost_matrix:
            tpt_cost = cost_matrix[tpt]
            if city in tpt_cost:
               tpt_cost[city]=price
      self.cost_matrix = cost_matrix

   
   def getLoadSheet(self):
      fname = QFileDialog.getOpenFileName(self, 'Open Load Sheet', 
         '.',"xlsx files (*.xlsx)")
      if fname is not None:
         if os.path.exists(fname[0]):
            # print(fname,self.costFileName)
            self.loadSheetName=fname[0]
            self.getDestinationData()
            self.loadSheetFilePath.setText(fname[0])

   def getDestinationData(self):
      if self.loadSheetName is not None:
         duckdb.install_extension('spatial')
         duckdb.load_extension('spatial')
         
      #   SELECT Destination, Bay, Count(*) 
         rows = duckdb.sql(f"""
            select destination , count(*) from (select destination, bay, count(*) as count, row_number() over (partition by bay order by count desc) as rank
                           FROM st_read(
            '{self.loadSheetName }') group by destination, bay) where rank = 1 group by destination order by destination
    """)
         
         # print(rows)
         # while row := rows.fetchone():
         #    print(dict(zip(rows.columns, row)))
         while row := rows.fetchone():
            for i in range(len(self.destination)):
               if self.destination[i].value.lower()==row[0].lower():
                  self.destination[i].isChecked=True
                  self.demand[self.destination[i].value]=row[1]
                  break
         self.originalDemand=self.demand.copy()
         self.onDestinationDialogClosed(self.destination)
         
   def getEntrySheet(self):
      fname = QFileDialog.getOpenFileName(self, 'Open Entry Sheet', 
         '.',"xlsx files (*.xlsx)")
      if fname is not None:
         if os.path.exists(fname[0]):
            self.entrySheetName=fname[0]
            self.getTransporterData()
            self.entrySheetFilePath.setText(fname[0])

   def getTransporterData(self):
      if self.entrySheetName is not None:
         entry_sheet_raw= pd.read_excel(self.entrySheetName,header=2)
         entry_sheet_raw.fillna(0,inplace=True)
         for i in range(len(entry_sheet_raw.index)):
            for j in range(len(self.transporter)):
               if self.transporter[j].value.upper()==entry_sheet_raw.iloc[i]['Unnamed: 0'].upper():
                  self.transporter[j].isChecked=True
                  self.supply[self.transporter[j].value]=entry_sheet_raw.iloc[i]['Total']+entry_sheet_raw.iloc[i]['Total.1']+entry_sheet_raw.iloc[i]['Total.2']+entry_sheet_raw.iloc[i]['Total.3']
                  self.minimumLoad[self.transporter[j].value]=0
                  break
            
         self.originalSupply=self.supply.copy()
         self.onTransporterDialogClosed(self.transporter)

   def createNumberBox(self, lowBound=1,highBound=1000000):
      numberBox = QLineEdit()
      numberBox.setFont(self.labelFont)
      numberBox.setAlignment(Qt.AlignCenter)
      numberBox.setValidator(QIntValidator(lowBound, highBound, self))
      return numberBox
   
   def nextBtnHandler(self):
      if len(self.demand)==0 or len(self.supply)==0:
         self.show_error_message("Destination and Transporter list cannot be empty!!!")
         return
      demand={}
      for i in range(self.destinationTable.rowCount()):
         if not self.destinationTable.isRowHidden(i):
            item = self.destinationTable.cellWidget(i, 0)  
            if item:
               city = item.text()
               demand[city.capitalize()]=self.originalDemand[city.capitalize()]
      self.demand = demand
      
      supply={}
      for i in range(self.transporterTable.rowCount()):
         if not self.transporterTable.isRowHidden(i):
            item = self.transporterTable.cellWidget(i, 0)  
            if item:
               tpt = item.text()
               supply[tpt.upper()]=self.originalSupply[tpt.upper()]
      self.supply = supply
      # if len(self.supply)==0:
      #    self.show_error_message("Empty Transporter List","Transporter cannot be empty!!!")
      #    return
      self.allocationHistory=[]
      self.allocation = {}
      for city in self.demand.keys():
         cityAllocation={}
         for tpt in self.supply.keys():
            if len(cityAllocation)== 0:
               cityAllocation[tpt]={"value":0,"state":AllocationState.RELEASE}
            else:
               cityAllocation[tpt]={"value":1,"state":AllocationState.RELEASE}
         self.allocation[city]=cityAllocation
      self.bodyFrame.hide()
      self.setupAllocationTable()
      self.allocationFrame.show()
      if self.allocationMatrix.horizontalScrollBar().isVisible():
         self.allocationMatrix.setMaximumHeight(self.allocationMatrix.maximumHeight()+self.allocationMatrix.horizontalScrollBar().height())
      if self.allocationMatrix.verticalScrollBar().isVisible():
         self.allocationMatrix.setMaximumWidth(self.allocationMatrix.maximumWidth()+self.allocationMatrix.verticalScrollBar().width())

   def backBtnHandler(self):
      self.allocationFrame.hide()
      self.bodyFrame.show()
   
   def addDestinationBtnHandler(self):
      destination=[]
      for i in range(len(self.destination)):
         if self.regionFilterComboBox.currentText().capitalize() == "All" or self.destination[i].value.capitalize() in self.region[self.regionFilterComboBox.currentText().capitalize()]['destination']:
            destination.append(self.destination[i])

      dialog = CategorySelector(destination)
      dialog.dialogClosed.connect(self.onDestinationDialogClosed)
      dialog.exec_()

   def clearDestinationBtnHandler(self):
      for category in self.destination:
         category.isChecked=False
      self.destinationTable.clearContents()
      self.demand.clear()


   def reAllocateBtnHandler(self):
      self.bodyFrame.hide()
      self.setupAllocationTable()
      self.allocationFrame.show()
      if self.allocationMatrix.horizontalScrollBar().isVisible():
         self.allocationMatrix.setMaximumHeight(self.allocationMatrix.maximumHeight()+self.allocationMatrix.horizontalScrollBar().height())
      if self.allocationMatrix.verticalScrollBar().isVisible():
         self.allocationMatrix.setMaximumWidth(self.allocationMatrix.maximumWidth()+self.allocationMatrix.verticalScrollBar().width())
   
   def exportBtnHandler(self):
      # self.reAllocateBtnHandler()
      try:
         exportWorkBook = xlsxwriter.Workbook("Allocation_File_"+datetime.now().strftime('%Y%m%d%H%M%S')+".xlsx")
         headingFormat = exportWorkBook.add_format({'bold': True, 'bg_color': '#C0C0C0'})
         currencyFormat = exportWorkBook.add_format({'num_format': '₹#,##0.00'})
         savingsCurrencyFormat = exportWorkBook.add_format({'num_format': '₹#,##0.00', 'bg_color': '#C6EFCE'})
         allocationFormat = exportWorkBook.add_format({'bg_color': '#C6EFCE'})
         supply_demand = exportWorkBook.add_worksheet('Supply and Demand')
         supply_demand.write('A1','Destination',headingFormat)
         supply_demand.write('B1','Demand',headingFormat)
         supply_demand.write('D1','Transporter',headingFormat)
         supply_demand.write('E1','Supply',headingFormat)
         supply_demand.write('F1','Minimum',headingFormat)

         transporter = sorted(list(self.supply.keys()))
         destination = sorted(list(self.demand.keys()))
         i=1
         for city in destination:
            supply_demand.write(i,0,city)
            supply_demand.write(i,1,self.demand[city])
            i+=1
         i=1
         for tpt in transporter:
            supply_demand.write(i,3,tpt)
            supply_demand.write(i,4,self.supply[tpt])
            supply_demand.write(i,5,self.minimumLoad[tpt])
            i+=1
         supply_demand.autofit() 

         allocation_entry = exportWorkBook.add_worksheet('Allocation Entry')
         j=0
         for heading in ['Destination','Transporter','Load']:
            allocation_entry.write(0,j,heading,headingFormat)
            j+=1
         i=1
         for city in self.demand.keys():
            for tpt in self.supply.keys():
               if self.allocation[city][tpt]['value'] != 0:
                  allocation_entry.write(i,0,city)
                  allocation_entry.write(i,1,tpt)
                  allocation_entry.write(i,2,self.allocation[city][tpt]['value'])
                  i+=1
         allocation_entry.autofit()
         allocation_matrix = exportWorkBook.add_worksheet('Allocation Matrix')
         max_matrix_len = max([len(row) for row in self.supply.keys()])
         max_city_len = max([len(row) for row in self.demand.keys()])
         
         allocation_matrix.write(0,0,"",headingFormat)
         allocation_matrix.set_column(1,len(self.supply)-1,max_matrix_len+2)
         j=1
         allocation_matrix.set_column(0,0,max_city_len+2)
         for tpt in self.supply.keys():
            allocation_matrix.write(0,j,tpt,headingFormat)
            j+=1
         i=1
         for city in self.demand.keys():
            allocation_matrix.write(i,0,city,headingFormat)
            j=1
            for tpt in self.supply.keys():
               if self.allocation[city][tpt]['value'] != 0:
                  allocation_matrix.write(i,j,self.allocation[city][tpt]['value'],allocationFormat)
               else:
                  allocation_matrix.write(i,j,self.allocation[city][tpt]['value'])
               j+=1
            allocation_matrix.write(i,j,self.demand[city])
            i+=1
         j=1
         for tpt in self.supply.keys():
            allocation_matrix.write(i,j,self.supply[tpt])
            j+=1
         i+=3
         allocation_matrix.write(i,0,"",headingFormat)
         # allocation_matrix.set_column(1,len(self.supply)-1,max_matrix_len+2)
         # j=1
         # allocation_matrix.set_column(i,0,max_city_len+2)
         j=1
         for tpt in self.supply.keys():
            allocation_matrix.write(i,j,tpt,headingFormat)
            j+=1
         i+=1
         for city in self.demand.keys():
            allocation_matrix.write(i,0,city,headingFormat)
            j=1
            for tpt in self.supply.keys():
               if self.allocation[city][tpt]['value'] != 0:
                  allocation_matrix.write(i,j,self.cost_matrix[tpt][city],allocationFormat)
               else:
                  allocation_matrix.write(i,j,self.cost_matrix[tpt][city])
               j+=1
            i+=1   

         
         i+=3
         allocation_matrix.merge_range(i-1,0,i-1,len(self.supply.keys()),'TTA Allocation', headingFormat)
         allocation_matrix.write(i,0,"",headingFormat)
         j=1
         for tpt in self.supply.keys():
            allocation_matrix.write(i,j,tpt,headingFormat)
            j+=1
         i+=1
         for city in self.demand.keys():
            allocation_matrix.write(i,0,city,headingFormat)
            j=1
            for tpt in self.supply.keys():
               if tpt in self.ttaAllocation[city].keys():
                  allocation_matrix.write(i,j,self.ttaAllocation[city][tpt],allocationFormat)
               else:
                  allocation_matrix.write(i,j,0)
               j+=1
            i+=1      
         allocation_matrix.autofit()
         rej_lock_entry = exportWorkBook.add_worksheet('Rejected and Locked Allocation')
         j=0
         for heading in ['S.No','Transporter','Destination','Status']:
            rej_lock_entry.write(0,j,heading,headingFormat)
            j+=1
         i=1
         for tpt in self.supply.keys():
            for city in self.demand.keys():
               if self.allocation[city][tpt]['state'] == AllocationState.BLOCKED or self.allocation[city][tpt]['state'] == AllocationState.LOCKED:
                  rej_lock_entry.write(i,0,i)
                  rej_lock_entry.write(i,1,tpt)
                  rej_lock_entry.write(i,2,city)
                  if self.allocation[city][tpt]['state'] == AllocationState.BLOCKED:
                     rej_lock_entry.write(i,3,"Rejected")
                  else:
                     rej_lock_entry.write(i,3,"Locked")
                  i+=1
         optimal_cost = self.allocationHistory[0][1]*(int(self.carrierNumberBox.text()) if self.carrierNumberBox.text() is not None else 1 )
         actual_cost = self.optimalCost*(int(self.carrierNumberBox.text()) if self.carrierNumberBox.text() is not None else 1 )

         rej_lock_entry.write(0,5,"Optimal Cost",headingFormat)
         rej_lock_entry.write(0,6,optimal_cost,currencyFormat)
         rej_lock_entry.write(1,5,"Actual Cost",headingFormat)
         rej_lock_entry.write(1,6,actual_cost,currencyFormat)
         rej_lock_entry.write(2,5,"Difference",headingFormat)
         rej_lock_entry.write(2,6,actual_cost-optimal_cost,currencyFormat)
         rej_lock_entry.write(3,5,"Cost Overrun Rate ",headingFormat)
         rej_lock_entry.write(3,6,round((actual_cost-optimal_cost)/optimal_cost,5))
         rej_lock_entry.write(4,5,"TTA Cost",headingFormat)
         rej_lock_entry.write(4,6,self.ttaAllocationCost,currencyFormat)
         rej_lock_entry.write(5,5,"Total Cost Savings",headingFormat)
         
         rej_lock_entry.write(5,6,self.ttaAllocationCost-optimal_cost,savingsCurrencyFormat)
         rej_lock_entry.autofit()

         exportWorkBook.close()
         self.show_message("Transport Allocation exported successfully!!!")
      except Exception as e:
         self.show_error_message(f"Error occurred: {e}")
   def onDestinationDialogClosed(self, result):
      self.destination = result
      self.originalDemand={}
      demand={}
      for category in self.destination:
         if category.isChecked:
            if category.value not in self.demand.keys():
               demand[category.value]=0 
            else:
               demand[category.value]=self.demand[category.value]
      self.updateDemandTotal()
      self.demand = demand
      self.originalDemand=self.demand.copy()
      self.fillDestinationTable()
   
   def setupTitleLayout(self):
      titleFrame = QFrame()
      # titleFrame.setStyleSheet("background:white")
      titleLayout = QHBoxLayout() 

      #Logo
      self.logoLbl = QLabel()
      logoPath = os.path.join(self.base_path, "images", "Renault_Nissan_logo.jpg")
      self.pixmap = QPixmap(logoPath)
      self.pixmap = self.pixmap.scaled(QSize(300,60))
      self.logoLbl.setPixmap(self.pixmap)
      self.logoLbl.resize(self.pixmap.width(), self.pixmap.height())
      titleLayout.addWidget(self.logoLbl)

      #Header
      # titleLayout.setSizeConstraint(QLayout.SetFixedSize)
      self.companyLbl = QLabel("TRANSPORT ALLOCATOR")
      self.titleFont = QFont("Helvetica", 12)
      self.titleFont.setBold(True)
      self.companyLbl.setFont(self.titleFont)
      titleLayout.addWidget(self.companyLbl)
      titleFrame.setStyleSheet("background-color:white")
      titleLayout.setContentsMargins(0,0,300,0)
      titleFrame.setLayout(titleLayout)
      return titleFrame

   def setupBodyLayout(self):
      bodyLayout = QVBoxLayout()
      self.bodyFrame = QFrame()

      costLayout = self.setupCostFileLayout()
      bodyLayout.addLayout(costLayout)
      loadLayout = self.setupLoadSheetLayout()
      bodyLayout.addLayout(loadLayout)
      entryLayout = self.setupEntrySheetLayout()
      bodyLayout.addLayout(entryLayout)
      # regionLayout = self.setupRegionLayout()
      # bodyLayout.addLayout(regionLayout)

      supplyDemandLayout = self.setupDemandSupplyLayout()
      bodyLayout.addLayout(supplyDemandLayout)

      footerLayout = self.setupNextFooterLayout()
      bodyLayout.addLayout(footerLayout)

      self.bodyFrame.setLayout(bodyLayout)
      return self.bodyFrame      
      
   def setupCostFileLayout(self):
      costLayout = QHBoxLayout()

      #Cost File Label
      self.costFileLbl = QLabel("Cost File")
      self.costFileLbl.setFont(self.labelFont)
      self.costFileLbl.setFixedWidth(105)
      costLayout.addWidget(self.costFileLbl)
		
      #Cost File Path TextBox
      self.costFilePath = QLineEdit()
      self.costFilePath.setFont(self.labelFont)
      if os.path.exists(self.costFileName):
         self.getData(self.costFileName)
         self.costFilePath.setText(os.path.abspath(self.costFileName))
      
      self.costFilePath.setAlignment(Qt.AlignVCenter)
      self.costFilePath.setFixedHeight(40)
      costLayout.addWidget(self.costFilePath)
      
      #Browse Button
      self.browseBtn = QPushButton("Browse")
      self.browseBtn.setFont(self.labelFont)
      self.browseBtn.setFixedSize(120,40)
      self.browseBtn.clicked.connect(self.getCostFile)
      costLayout.addWidget(self.browseBtn)
      return costLayout   

   def setupLoadSheetLayout(self):
      loadLayout = QHBoxLayout()

      #Cost File Label
      self.loadSheetLbl = QLabel("Load Sheet")
      self.loadSheetLbl.setFont(self.labelFont)
      self.loadSheetLbl.setFixedWidth(105)
      loadLayout.addWidget(self.loadSheetLbl)
		
      #Cost File Path TextBox
      self.loadSheetFilePath = QLineEdit()
      self.loadSheetFilePath.setFont(self.labelFont)
      # if os.path.exists(self.costFileName):
      #    self.getData(self.costFileName)
      #    self.loadSheetFilePath.setText(os.path.abspath(self.costFileName))
      
      self.loadSheetFilePath.setAlignment(Qt.AlignVCenter)
      self.loadSheetFilePath.setFixedHeight(40)
      loadLayout.addWidget(self.loadSheetFilePath)
      
      #Browse Button
      self.loadBrowseBtn = QPushButton("Browse")
      self.loadBrowseBtn.setFont(self.labelFont)
      self.loadBrowseBtn.setFixedSize(120,40)
      self.loadBrowseBtn.clicked.connect(self.getLoadSheet)
      loadLayout.addWidget(self.loadBrowseBtn)
      return loadLayout
    
   def setupEntrySheetLayout(self):
      entryLayout = QHBoxLayout()

      #Cost File Label
      self.entrySheetLbl = QLabel("Entry Sheet")
      self.entrySheetLbl.setFont(self.labelFont)
      self.entrySheetLbl.setFixedWidth(105)
      entryLayout.addWidget(self.entrySheetLbl)
		
      #Cost File Path TextBox
      self.entrySheetFilePath = QLineEdit()
      self.entrySheetFilePath.setFont(self.labelFont)
      # if os.path.exists(self.costFileName):
      #    self.getData(self.costFileName)
      #    self.loadSheetFilePath.setText(os.path.abspath(self.costFileName))
      
      self.entrySheetFilePath.setAlignment(Qt.AlignVCenter)
      self.entrySheetFilePath.setFixedHeight(40)
      entryLayout.addWidget(self.entrySheetFilePath)
      
      #Browse Button
      self.entryBrowseBtn = QPushButton("Browse")
      self.entryBrowseBtn.setFont(self.labelFont)
      self.entryBrowseBtn.setFixedSize(120,40)
      self.entryBrowseBtn.clicked.connect(self.getEntrySheet)
      entryLayout.addWidget(self.entryBrowseBtn)
      return entryLayout 
   
   def setupRegionLayout(self):
      regionLayout = QHBoxLayout()

      #Cost File Label
      self.regionLbl = QLabel("Region")
      self.regionLbl.setFont(self.labelFont)
      self.regionLbl.setFixedWidth(105)
      regionLayout.addWidget(self.regionLbl)

      self.regionFilterComboBox = QComboBox(self)
      self.regionFilterComboBox.setFont(self.labelFont)
      self.regionFilterComboBox.setFixedSize(100,40)
      self.regionFilterComboBox.setStyleSheet("QComboBox { padding-left:10px; } ")
      self.regionFilterComboBox.addItems(["All","North","NEast", "South","East","West"])
      self.regionFilterComboBox.currentIndexChanged.connect(self.regionComboBoxChangedHandler)
      self.regionFilterComboBox.setInsertPolicy(QComboBox.NoInsert)
      regionLayout.addWidget(self.regionFilterComboBox)
      return regionLayout

   def setupDemandSupplyLayout(self):
      supplyDemandLayout = QHBoxLayout()
      
      demandFrame = self.setupDemandLayout()      
      supplyDemandLayout.addWidget(demandFrame)
         
      supplyFrame = self.setupSupplyLayout()
      supplyDemandLayout.addWidget(supplyFrame)

      # allocationFrame = self.setupAllocationMatrix()
      # supplyDemandLayout.addWidget(allocationFrame)

      return supplyDemandLayout
   
   def regionComboBoxChangedHandler(self):
      selected_option = self.regionFilterComboBox.currentText()
      for i in range(self.destinationTable.rowCount()):
         item = self.destinationTable.cellWidget(i, 0)  
         # print('item',item)
         if item:
            city = item.text()
            self.destinationTable.setRowHidden(i, not(selected_option.capitalize()=="All" or city.capitalize() in self.region[selected_option.capitalize()]['destination']))
      
      for i in range(self.transporterTable.rowCount()):
         item = self.transporterTable.cellWidget(i, 0)  
         if item:
            tpt = item.text()
            self.transporterTable.setRowHidden(i, not(selected_option.capitalize()=="All" or tpt.capitalize() in self.region[selected_option.capitalize()]['transporter']))
      # self.region[selected_option.capitalize()]['transporter']

   def updateDemandTotal(self):
      totalDemand=0
      for city in self.demand.keys():
         totalDemand+=self.demand[city]
      self.fixedDemandTotal.setHorizontalHeaderLabels(["Total", str(totalDemand)])

   def setupDemandLayout(self):
      demandLayout = QVBoxLayout()
      demandHeaderLayout = QHBoxLayout()
      self.demandHeader = QLabel("Destination")
      self.demandHeader.setFont(self.labelFont)
      demandHeaderLayout.addWidget(self.demandHeader)
      self.destinationClearButton = QPushButton("Clear")
      self.destinationClearButton.setFont(self.labelFont)
      self.destinationClearButton.setFixedSize(100,40)
      self.destinationClearButton.clicked.connect(self.clearDestinationBtnHandler)
      demandHeaderLayout.addWidget(self.destinationClearButton)
      self.destinationAddButton = QPushButton("Add +")
      self.destinationAddButton.setFont(self.labelFont)
      self.destinationAddButton.setFixedSize(100,40)
      self.destinationAddButton.clicked.connect(self.addDestinationBtnHandler)
      demandHeaderLayout.addWidget(self.destinationAddButton)
      demandLayout.addLayout(demandHeaderLayout)

      self.destinationTable = QTableWidget()
      self.destinationTable.verticalHeader().setVisible(False)
      self.destinationTable.setColumnCount(2)
      self.destinationTable.setHorizontalHeaderLabels(["Destination","Demand"])
      destinationTableHeader = self.destinationTable.horizontalHeader()
      destinationTableHeader.setFont(self.labelFont)
      destinationTableHeader.setFixedHeight(50)
      destinationTableHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      destinationTableHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
      destinationTableHeader.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
      self.destinationTable.setRowCount(0)
      self.fillDestinationTable()
      demandLayout.addWidget(self.destinationTable)
      
      self.fixedDemandTotal = QTableWidget(0, 2)  # One row, same columns
      self.fixedDemandTotal.setFixedHeight(50)
      self.fixedDemandTotal.setHorizontalHeaderLabels(["Total", "0",])
      fixedDemandTotalHeader = self.fixedDemandTotal.horizontalHeader()
      fixedDemandTotalHeader.setFixedHeight(50)
      fixedDemandTotalHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      fixedDemandTotalHeader.setFont(self.labelFont)
      fixedDemandTotalHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
      fixedDemandTotalHeader.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
      demandLayout.addWidget(self.fixedDemandTotal)
      self.demandFrame = QFrame()
      self.demandFrame.setLayout(demandLayout)
      return self.demandFrame
   
   def fillDestinationTable(self):
      self.destinationTable.setRowCount(0)
      for city in self.demand.keys():
         currPos = self.destinationTable.rowCount()
         self.destinationTable.insertRow(currPos)
         label = QLabel(city)
         label.setFont(self.labelFont)
         label.setStyleSheet("padding-left:10px;")
         self.destinationTable.setCellWidget(currPos,0,label)
         numberBox = self.createNumberBox()
         numberBox.setProperty("city", city)
         if self.demand[city] != 0:
            numberBox.setText(str(self.demand[city]))
         numberBox.textChanged.connect(self.onDemandChanged)
         self.destinationTable.setCellWidget(currPos,1,numberBox)
   
   @pyqtSlot(str)
   def onDemandChanged(self,text):
      sender = self.sender()
      city = sender.property("city")
      if text is None or text == "":
         self.demand[city] = 0
      else:
         self.demand[city] = int(text)
      self.originalDemand[city]=self.demand[city]
      self.updateDemandTotal()

   def updateSupplyTotal(self):
      totalSupply=0
      for tpt in self.supply.keys():
         totalSupply+=self.supply[tpt]
      self.fixedSupplyTotal.setHorizontalHeaderLabels(["Total", str(totalSupply)])

   def setupSupplyLayout(self):
      supplyLayout = QVBoxLayout()

      #Supply Header
      supplyHeaderLayout = QHBoxLayout()
      self.supplyHeader = QLabel("Transporter")
      self.supplyHeader.setFont(self.labelFont)
      supplyHeaderLayout.addWidget(self.supplyHeader)

      #Clear Button
      self.transporterClearButton = QPushButton("Clear")
      self.transporterClearButton.setFont(self.labelFont)
      self.transporterClearButton.setFixedSize(100,40)
      self.transporterClearButton.clicked.connect(self.clearTransporterBtnHandler)
      supplyHeaderLayout.addWidget(self.transporterClearButton)

      #Add Button
      self.transporterAddButton = QPushButton("Add +")
      self.transporterAddButton.setFont(self.labelFont)
      self.transporterAddButton.setFixedSize(100,40)
      self.transporterAddButton.clicked.connect(self.addTransporterBtnHandler)
      supplyHeaderLayout.addWidget(self.transporterAddButton)
      supplyLayout.addLayout(supplyHeaderLayout)

      #Transporter Table
      self.transporterTable = QTableWidget()
      self.transporterTable.verticalHeader().setVisible(False)
      self.transporterTable.setColumnCount(3)
      self.transporterTable.setHorizontalHeaderLabels(["Transporter","Capacity","Minimum"])
      transporterTableHeader = self.transporterTable.horizontalHeader()
      transporterTableHeader.setFont(self.labelFont)
      transporterTableHeader.setFixedHeight(50)
      transporterTableHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      transporterTableHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
      transporterTableHeader.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
      transporterTableHeader.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
      self.transporterTable.setRowCount(0)
      self.fillTransporterTable()
      supplyLayout.addWidget(self.transporterTable)
      self.fixedSupplyTotal = QTableWidget(0, 2)  # One row, same columns
      self.fixedSupplyTotal.setFixedHeight(50)
      self.fixedSupplyTotal.setHorizontalHeaderLabels(["Total", "0",])
      fixedSupplyTotalHeader = self.fixedSupplyTotal.horizontalHeader()
      fixedSupplyTotalHeader.setFixedHeight(50)
      fixedSupplyTotalHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      fixedSupplyTotalHeader.setFont(self.labelFont)
      fixedSupplyTotalHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
      fixedSupplyTotalHeader.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
      supplyLayout.addWidget(self.fixedSupplyTotal)
      self.supplyFrame = QFrame()
      self.supplyFrame.setLayout(supplyLayout)
      # self.supplyFrame.setStyleSheet("padding:0")
      return self.supplyFrame
   
   def fillTransporterTable(self):
      self.transporterTable.setRowCount(0)
      for tpt in self.supply.keys():
         currPos = self.transporterTable.rowCount()
         self.transporterTable.insertRow(currPos)
         label = QLabel(tpt)
         label.setFont(self.labelFont)
         label.setStyleSheet("padding-left:10px;")
         self.transporterTable.setCellWidget(currPos,0,label)
         numberBox = self.createNumberBox()
         numberBox.setProperty("tpt", tpt)
         if self.supply[tpt] != 0:
            numberBox.setText(str(self.supply[tpt]))
         numberBox.textChanged.connect(self.onSupplyChanged)
         self.transporterTable.setCellWidget(currPos,1,numberBox)
         numberBox = self.createNumberBox()
         numberBox.setProperty("tpt", tpt)
         if self.minimumLoad[tpt] != 0:
            numberBox.setText(str(self.minimumLoad[tpt]))
         numberBox.textChanged.connect(self.onMiniumLoadChanged)
         self.transporterTable.setCellWidget(currPos,2,numberBox)
   
   @pyqtSlot(str)
   def onSupplyChanged(self,text):
      sender = self.sender()
      tpt = sender.property("tpt")
      if text is None or text == "":
         self.supply[tpt] = 0
      else:
         self.supply[tpt] = int(text)
      self.originalSupply[tpt] = self.supply[tpt]
      self.updateSupplyTotal()
      
   @pyqtSlot(str)
   def onMiniumLoadChanged(self,text):
      sender = self.sender()
      tpt = sender.property("tpt")
      if text is None or text == "":
         self.minimumLoad[tpt] = 0
      else:
         self.minimumLoad[tpt] = int(text)
   
   def addTransporterBtnHandler(self):
      dialog = CategorySelector(self.transporter)
      dialog.dialogClosed.connect(self.onTransporterDialogClosed)
      dialog.exec_()
   
   def clearTransporterBtnHandler(self):
      for category in self.transporter:
         category.isChecked=False
      self.transporterTable.clearContents()
      self.supply.clear()
      self.minimumLoad.clear()
   
   def onTransporterDialogClosed(self, result):
      self.transporter = result
      supply={}
      self.originalSupply={}
      minLoad={}
      for category in self.transporter:
         if category.isChecked:
            if category.value not in self.supply.keys():
               supply[category.value]=0 
               minLoad[category.value]=0 
            else:
               supply[category.value]=self.supply[category.value]
               minLoad[category.value]=self.minimumLoad[category.value]
      self.updateSupplyTotal()
      self.supply = supply
      self.originalSupply=self.supply.copy()
      self.minimumLoad = minLoad
      self.fillTransporterTable()
  
   def setupNextFooterLayout(self):
      footerLayout = QHBoxLayout()
   
      self.regionLbl = QLabel("Region")
      self.regionLbl.setFont(self.labelFont)
      self.regionLbl.setFixedWidth(105)
      footerLayout.addWidget(self.regionLbl,0,alignment=Qt.AlignLeft)
      footerLayout.setStretchFactor(self.regionLbl, 0)
      self.regionFilterComboBox = QComboBox(self)
      self.regionFilterComboBox.setFont(self.labelFont)
      self.regionFilterComboBox.setFixedSize(100,40)
      self.regionFilterComboBox.setStyleSheet("QComboBox { padding-left:10px; } ")
      self.regionFilterComboBox.addItems(["All","North","NEast", "South","East","West"])
      self.regionFilterComboBox.currentIndexChanged.connect(self.regionComboBoxChangedHandler)
      self.regionFilterComboBox.setInsertPolicy(QComboBox.NoInsert)
      footerLayout.addWidget(self.regionFilterComboBox,alignment=Qt.AlignLeft)
      footerLayout.setStretchFactor(self.regionFilterComboBox, 0)
      

      # spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
      # footerLayout.addSpacerItem(spacer)
      
      footerLayout.addStretch(1)
      #Next Button
      self.nextBtn = QPushButton("Allocate")
      self.nextBtn.setFont(self.labelFont)
      self.nextBtn.setFixedSize(120,40)
      self.nextBtn.clicked.connect(self.nextBtnHandler)
      footerLayout.addWidget(self.nextBtn,alignment=Qt.AlignRight)
      return footerLayout
   
   def setupFinalFooterLayout(self):
      finalFooterLayout=QVBoxLayout()
      costStatmentLayout = QHBoxLayout()
      costStatmentLayout.setSpacing(0)
      leftSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
      costStatmentLayout.addItem(leftSpacer)
      finalStatement1=QLabel('The optimal allocation cost for ')
      finalStatement1.setFont(self.labelFont)
      costStatmentLayout.addWidget(finalStatement1)
      self.carrierNumberBox = self.createNumberBox()
      self.carrierNumberBox.setFixedHeight(40)
      self.carrierNumberBox.setFixedWidth(50)
      costStatmentLayout.addWidget(self.carrierNumberBox)
      finalStatement2=QLabel(' carrier is ')
      finalStatement2.setFont(self.labelFont)
      costStatmentLayout.addWidget(finalStatement2)
      self.carrierNumberBox.setText("8")
      self.carrierNumberBox.textChanged.connect(self.onCarrierChanged)
   
      self.amountNumberBox = QLineEdit()
      self.amountNumberBox.setFont(self.labelFont)
      self.amountNumberBox.setFixedHeight(40)
      self.amountNumberBox.setFixedWidth(200)
      self.amountNumberBox.setDisabled(True)
      doubleValidator = QDoubleValidator()
      doubleValidator.setRange(0,100000000)
      doubleValidator.setDecimals(2)
      self.amountNumberBox.setValidator(doubleValidator)
      costStatmentLayout.addWidget(self.amountNumberBox)      
      rightSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
      costStatmentLayout.addItem(rightSpacer)
      self.allocationHistoryBtn = QPushButton('History')
      self.allocationHistoryBtn.setFont(self.labelFont)
      self.allocationHistoryBtn.setFixedSize(120,40)
      self.allocationHistoryBtn.clicked.connect(self.onAllocationHistoryBtnClicked)
      costStatmentLayout.addWidget(self.allocationHistoryBtn)
      endSpacer = QSpacerItem(25, 20)
      costStatmentLayout.addItem(endSpacer)

      finalFooterLayout.addLayout(costStatmentLayout)
      
      allocationPageOptionLayout = QHBoxLayout()
      #Back Button

      self.backBtn = QPushButton("Back")
      self.backBtn.setFont(self.labelFont)
      self.backBtn.setFixedSize(120,40)
      self.backBtn.clicked.connect(self.backBtnHandler)
      allocationPageOptionLayout.addWidget(self.backBtn)
      
      #Re-Allocate Button
      self.reAllocateBtn = QPushButton("Re-Allocate")
      self.reAllocateBtn.setFont(self.labelFont)
      self.reAllocateBtn.setFixedSize(120,40)
      self.reAllocateBtn.clicked.connect(self.reAllocateBtnHandler)
      allocationPageOptionLayout.addWidget(self.reAllocateBtn)
      
      #Next Button
      self.exportBtn = QPushButton("Export")
      self.exportBtn.setFont(self.labelFont)
      self.exportBtn.setFixedSize(120,40)
      self.exportBtn.clicked.connect(self.exportBtnHandler)
      allocationPageOptionLayout.addWidget(self.exportBtn)
      
      allocationPageOptionLayout.addStretch()
      allocationPageOptionLayout.setDirection(QBoxLayout.RightToLeft)
      finalFooterLayout.addLayout(allocationPageOptionLayout)

      return finalFooterLayout
   
   def onAllocationHistoryBtnClicked(self):
      self.allocationHistoryContainer.setHidden(not self.allocationHistoryContainer.isHidden())

   def onCarrierChanged(self,text):
      if text is None or text == "":
         self.amountNumberBox.setText(self.getRupeeFormat(round(self.optimalCost,2)))
      else:
         self.amountNumberBox.setText(self.getRupeeFormat(round(self.optimalCost*int(text),2)))


   def setupAllocationPage(self):
      allocationFrame = QFrame()
      allocationPageLayout = QVBoxLayout()
      allocationLayout = QHBoxLayout()
      allocationMatrixLayout = self.setupAllocationMatrix()
      allocationMatrixContainer = QWidget()
      allocationMatrixContainer.setLayout(allocationMatrixLayout)
      allocationLayout.addWidget(allocationMatrixContainer)
      allocationLayout.setStretchFactor(allocationMatrixContainer, 1)
      allocationHistoryLayout=self.setupAllocationHistoryTab()
      self.allocationHistoryContainer = QWidget()
      self.allocationHistoryContainer.setLayout(allocationHistoryLayout)
      allocationLayout.addWidget(self.allocationHistoryContainer)
      allocationLayout.setStretchFactor(self.allocationHistoryContainer, 0)
      allocationLayout.addLayout(allocationHistoryLayout,0)
      self.allocationContainer = QWidget()
      self.allocationContainer.setLayout(allocationLayout)
      allocationPageLayout.addWidget(self.allocationContainer)
      allocationPageLayout.setStretchFactor(self.allocationContainer, 1)
      finalFooterLayout = self.setupFinalFooterLayout()
      allocationPageLayout.addLayout(finalFooterLayout)
      allocationPageLayout.addStretch()
      allocationFrame.setLayout(allocationPageLayout)
      allocationFrame.hide()
      return allocationFrame
   
   def updateAllocationTable(self):
      self.allocationHistoryTable.clear()
      self.lowestCost = 0
      if len(self.allocationHistory)>0:
         self.lowestCost = min(self.allocationHistory,key=lambda x:x[1])[1]
      for i in range(len(self.allocationHistory)):
         self.allocationHistoryTable.insertRow(i)
         historybtn = QPushButton()
         historybtn.setFont(self.labelFont)
         if self.allocationHistory[i][1]==self.lowestCost:
            historybtn.setStyleSheet("color:green")
         historybtn.setProperty("index",i)
         if self.allocationHistory[i][2]=="":
            allocationCost = self.allocationHistory[i][1]
         else:
            allocationCost = self.allocationHistory[i][1]*int(self.allocationHistory[i][2])
         historybtn.setText(self.getRupeeFormat(allocationCost))
         historybtn.clicked.connect(self.onHistoryBtnClicked)
         self.allocationHistoryTable.setCellWidget(i,0,historybtn)
      if len(self.allocationHistory) > 0:
         self.selectedAllocationHistoryIndex=len(self.allocationHistory)-1
         historybtn= self.allocationHistoryTable.cellWidget(len(self.allocationHistory)-1,0)
         if self.allocationHistory[ len(self.allocationHistory)-1][1]==self.lowestCost:
            historybtn.setStyleSheet("background:lightgrey;color:green;")
         else:
            historybtn.setStyleSheet("background:lightgrey")
         
         self.lowestCost = min(self.allocationHistory,key=lambda x:x[1])[1]
         allocationDifference=self.allocationHistory[len(self.allocationHistory)-1][1]-self.lowestCost
         self.setAllocationDifference(allocationDifference)

   def onHistoryBtnClicked(self):


      historybtn = self.allocationHistoryTable.cellWidget(self.selectedAllocationHistoryIndex,0)
      if self.allocationHistory[self.selectedAllocationHistoryIndex][1]==self.lowestCost:
         historybtn.setStyleSheet("background:white;color:green;")
      else:
         historybtn.setStyleSheet("background:white")
      
      senderBtn = self.sender()
      index = senderBtn.property("index")
      self.selectedAllocationHistoryIndex=index
      allocationDifference = self.allocationHistory[index][1]-self.lowestCost
      self.setAllocationDifference(allocationDifference)
      if self.allocationHistory[index][1]==self.lowestCost:
         senderBtn.setStyleSheet("background:lightgrey;color:green;")
      else:
         senderBtn.setStyleSheet("background:lightgrey")
      allocationCopy={}
      for city in self.allocationHistory[index][0].keys():
         temp={}
         for tpt in self.allocationHistory[index][0][city].keys():
            temp[tpt]={}
            temp[tpt]["value"]=self.allocationHistory[index][0][city][tpt]["value"]
            temp[tpt]["state"]=self.allocationHistory[index][0][city][tpt]["state"]
         allocationCopy[city]=temp
      self.allocation=allocationCopy
      self.optimalCost=self.allocationHistory[index][1]
      self.carrierNumberBox.setText(self.allocationHistory[index][2])
      self.onCarrierChanged(self.carrierNumberBox.text())
      
      self.fillAllocationTable()
      # self.amountNumberBox=self.allocationCostHistory[i]

   

   def setAllocationDifference(self, difference):
      if self.carrierNumberBox.text() is None or self.carrierNumberBox.text() == "":
         carrier=1
      else:
         carrier = int(self.carrierNumberBox.text())
      self.fixedAllocationDifference.setHorizontalHeaderLabels(["Difference", str(round(carrier*difference,2))])

   def setupAllocationHistoryTab(self):
      allocationHistoryLayout = QVBoxLayout()
      allocationHistoryTabLayout=QVBoxLayout()
      self.allocationHistoryTable = QTableWidget()
      self.allocationHistoryTable.verticalHeader().hide()
      self.allocationHistoryTable.horizontalHeader().hide()
      self.allocationHistoryTable.setColumnCount(1)
      self.allocationHistoryTable.setFrameStyle(QFrame.NoFrame)
      self.allocationHistoryTable.horizontalHeader().setStretchLastSection(True)
      allocationHistoryTabLayout.addWidget(self.allocationHistoryTable)
      allocationHistoryTab = QWidget()
      allocationHistoryTab.setLayout(allocationHistoryTabLayout)
      allocationHistoryTab.setStyleSheet("background:white")
      allocationHistoryTab.setFixedWidth(300)
      allocationHistoryLayout.addWidget(allocationHistoryTab)
      self.fixedAllocationDifference = QTableWidget(0, 2)  # One row, same columns
      self.fixedAllocationDifference.setFixedHeight(50)
      self.fixedAllocationDifference.setHorizontalHeaderLabels(["Difference", "0",])
      fixedAllocationDifferenceHeader = self.fixedAllocationDifference.horizontalHeader()
      fixedAllocationDifferenceHeader.setFixedHeight(50)
      fixedAllocationDifferenceHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      fixedAllocationDifferenceHeader.setFont(self.labelFont)
      fixedAllocationDifferenceHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
      fixedAllocationDifferenceHeader.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
      allocationHistoryLayout.addWidget(self.fixedAllocationDifference)
      allocationHistoryLayout.setStretchFactor(allocationHistoryTab, 1)
      self.updateAllocationTable()
      return allocationHistoryLayout

   def setupAllocationMatrix(self):
      allocationLayout = QHBoxLayout()
      self.allocationMatrix = QTableWidget()
      if not(len(self.supply)==0 or len(self.demand)==0):
         self.setupAllocationTable()
      # self.allocationMatrix.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
      allocationLayout.addWidget(self.allocationMatrix)
      return allocationLayout

   def setupAllocationTable(self):
      self.allocationMatrix.setColumnCount(len(self.supply))
      self.allocationMatrix.setRowCount(len(self.demand))
      self.allocationMatrix.setHorizontalHeaderLabels(self.supply.keys())
      self.allocationMatrix.setVerticalHeaderLabels(sorted(self.demand.keys()))
      self.allocationMatrix.setStyleSheet("""
            QTableCornerButton::section {
                background-color: lightgrey;
            }
        """)
      allocationMatrixHorizontalHeader = self.allocationMatrix.horizontalHeader()
      allocationMatrixHorizontalHeader.setFont(self.labelFont)
      allocationMatrixHorizontalHeader.setFixedHeight(50)
      allocationMatrixHorizontalHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      
      allocationMatrixVerticalHeader = self.allocationMatrix.verticalHeader()
      allocationMatrixVerticalHeader.setFont(self.labelFont)
      # allocationMatrixVerticalHeader.setFixedHeight(50)
      allocationMatrixVerticalHeader.setStyleSheet("QHeaderView::section { background-color: lightgrey ;}")
      for i in range(len(self.supply)):
         allocationMatrixHorizontalHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
      self.allocateTransport()
      self.fillAllocationTable()
      
   def fillAllocationTable(self):
      # self.allocationMatrix.setRowCount(0)
      i=0
      for city in self.demand.keys():
         j=0
         self.allocationMatrix.setRowHeight(i,50)
         for tpt in self.supply.keys():
            cellWidget = QPushButton()
            cellLayout = QHBoxLayout()
            cellLayout.setDirection(QBoxLayout.RightToLeft)
            logoLbl = QLabel()
            image_path = os.path.join(self.base_path, "images", "release.png")
            pixmap = QPixmap(image_path)
            pixmap = pixmap.scaled(QSize(28,28))
            logoLbl.setPixmap(pixmap)
            logoLbl.resize(pixmap.width(), pixmap.height())
            logoLbl.setContentsMargins(0,0,0,0)
            logoLbl.setFixedWidth(30)
            cellLayout.addWidget(logoLbl)
            
            textbox = self.createNumberBox()
            textbox.setAlignment(Qt.AlignLeft)
            textbox.setStyleSheet("background-color:rgba(0,0,0,0); border: none;")
            textbox.setFont(self.labelFont)
            textbox.setProperty("tpt",tpt)
            textbox.setProperty("city",city)
            if self.allocation[city][tpt]['value'] != 0:
               textbox.setText(str(self.allocation[city][tpt]['value']))
               # cellWidget.setStyleSheet("background-color:lightgreen")
            # else:
            #    cellWidget.setDisabled(True)
            textbox.setContentsMargins(0,0,0,0)
            textbox.textChanged.connect(self.onAllocationChange)
            cellLayout.addWidget(textbox,1) 
            cellLayout.setSpacing(0)
            cellWidget.setProperty("city",city)
            cellWidget.setProperty("tpt",tpt)
            cellWidget.setLayout(cellLayout)
            # cellWidget.setStyleSheet("background-color:red;padding:0px")
            cellWidget.setContentsMargins(0,0,0,0)
            if self.allocation[city][tpt]!=AllocationState.DISABLED:
               cellWidget.clicked.connect(self.onAllocationCellClicked)
            self.setAllocationState(cellWidget,city,tpt)
            self.allocationMatrix.setCellWidget(i,j,cellWidget)
            j+=1
         i+=1
      # self.allocationMatrix.setCellWidget
      
      table_width = self.allocationMatrix.verticalHeader().width() + self.allocationMatrix.horizontalHeader().length() + self.allocationMatrix.frameWidth() * 2
      table_height = self.allocationMatrix.horizontalHeader().height() + self.allocationMatrix.verticalHeader().length() + self.allocationMatrix.frameWidth() * 2
      self.allocationMatrix.setMaximumSize(table_width, table_height)
      self.AllocationChanged=False

   def onAllocationChange(self):
      sender = self.sender()
      tpt = sender.property("tpt")
      city = sender.property("city")
      self.allocation[city][tpt]['value']=sender.text()
      self.AllocationChanged=True


   def setAllocationState(self,senderBtn,city,tpt):
      hbox_layout = senderBtn.layout()
      if hbox_layout:
         allocationLbl = hbox_layout.itemAt(1).widget() 
      match self.allocation[city][tpt]['state']:
         case AllocationState.RELEASE:
            if allocationLbl is not None :
               if allocationLbl.text() is not None and allocationLbl.text() != "":
                  senderBtn.setStyleSheet("background-color:lightgreen;color:black")
                  logoPath = os.path.join(self.base_path, "images", "release.png")
               else:
                  senderBtn.setStyleSheet("background-color:white;color:black")
                  logoPath = os.path.join(self.base_path, "images", "release.png")
         case AllocationState.LOCKED:
            if allocationLbl is not None :
               if allocationLbl.text() is not None and allocationLbl.text() != "":
                  senderBtn.setStyleSheet("background-color:orange;color:white")
                  logoPath = os.path.join(self.base_path, "images", "lock.png")
         case AllocationState.BLOCKED:
            if allocationLbl is not None :
               senderBtn.setStyleSheet("background-color:#880808;color:white")
               logoPath = os.path.join(self.base_path, "images", "block.png")
         case AllocationState.DISABLED:
            senderBtn.setStyleSheet("background-color:grey;color:white")
            senderBtn.setEnabled(False)
      if self.allocation[city][tpt]['state']!= AllocationState.DISABLED and hbox_layout:
         logoLbl = hbox_layout.itemAt(0).widget() 
         pixmap = QPixmap(logoPath)
         pixmap = pixmap.scaled(QSize(28,28))
         logoLbl.setPixmap(pixmap)
         logoLbl.resize(pixmap.width(), pixmap.height())

   def changeAllocationState(self,senderBtn,city,tpt):
      hbox_layout = senderBtn.layout()
      if hbox_layout:
         allocationLbl = hbox_layout.itemAt(1).widget() 

      match self.allocation[city][tpt]['state']:
         case AllocationState.RELEASE:
            if allocationLbl is not None :
               if allocationLbl.text() is not None and allocationLbl.text() != "":
                  self.allocation[city][tpt]['state'] = AllocationState.LOCKED 
                  senderBtn.setStyleSheet("background-color:orange;color:white")
                  logoPath = os.path.join(self.base_path, "images", "lock.png")
               else:
                  self.allocation[city][tpt]['state'] = AllocationState.BLOCKED
                  senderBtn.setStyleSheet("background-color:#880808;color:white")
                  logoPath = os.path.join(self.base_path, "images", "block.png")

         case AllocationState.LOCKED:
            self.allocation[city][tpt]['state'] = AllocationState.BLOCKED
            senderBtn.setStyleSheet("background-color:#880808;color:white")
            logoPath = os.path.join(self.base_path, "images", "block.png")
         case AllocationState.BLOCKED:
            if allocationLbl is not None :
               if allocationLbl.text() is not None and allocationLbl.text() != "":
                  self.allocation[city][tpt]['state'] = AllocationState.RELEASE
                  senderBtn.setStyleSheet("background-color:lightgreen;color:black")
                  logoPath = os.path.join(self.base_path, "images", "release.png")
               else:
                  self.allocation[city][tpt]['state'] = AllocationState.RELEASE
                  senderBtn.setStyleSheet("background-color:white;color:black")
                  logoPath = os.path.join(self.base_path, "images", "release.png")
      if hbox_layout:
         logoLbl = hbox_layout.itemAt(0).widget() 
         pixmap = QPixmap(logoPath)
         pixmap = pixmap.scaled(QSize(28,28))
         logoLbl.setPixmap(pixmap)
         logoLbl.resize(pixmap.width(), pixmap.height())
      
   
   def onAllocationCellClicked(self):
      senderBtn = self.sender()
      city = senderBtn.property('city')
      tpt = senderBtn.property('tpt')
      self.changeAllocationState(senderBtn,city,tpt)
      self.AllocationChanged=True
      
      # hbox_layout = senderBtn.layout()
      # if hbox_layout:
      #    allocationLbl = hbox_layout.itemAt(1).widget() 
         # allocationLbl.setFocus()
      # senderBtn.setStyleSheet("background:")
   def makeDict(keys, data, default):
      return {key: {subkey: data[i][j] if i < len(data) and j < len(data[i]) else default for j, subkey in enumerate(keys[1])} for i, key in enumerate(keys[0])}
   
   def allocateTransport(self):
      # if not hasattr(self, "allocation") or len(self.allocation)==0:
         
      # Function to convert cost data into a dictionary
      supply = self.supply.copy()
      demand = self.demand.copy()
      transporter = sorted(list(supply.keys()))
      destination = sorted(list(demand.keys()))
      costs_dict = self.cost_matrix.copy()
      dummyDestination = 'zzz_dummydestination'
      if sum(supply.values())!=sum(demand.values()):
         demand[dummyDestination]=abs(sum(supply.values())-sum(demand.values()))
         destination.append(dummyDestination)
         for tpt in transporter:
            costs_dict[tpt][dummyDestination]=0

      prob = LpProblem("Material_Supply_Problem", LpMinimize)

      # Creates a list of tuples containing all the possible routes for transport
      Routes = [(tpt,city) for tpt in transporter for city in destination]
      # A dictionary called 'Vars' is created to contain the referenced variables(the routes)
      
      vars = dict()
      for tpt in transporter:
         vars[tpt]=dict()
         for city in destination:
               if city == dummyDestination:
                  vars[tpt][city] = LpVariable(tpt+ "_"+city,cat="Integer", lowBound=0)
               else:
                  if costs_dict[tpt][city]==INFINITY:
                     self.allocation[city][tpt]['state']=AllocationState.DISABLED
                  if self.allocation[city][tpt]['state'] == AllocationState.RELEASE:
                     vars[tpt][city] = LpVariable(tpt+ "_"+city,cat="Integer", lowBound = 0)
                  elif self.allocation[city][tpt]['state'] == AllocationState.BLOCKED:
                     vars[tpt][city] = LpVariable(tpt+ "_"+city,cat="Integer", lowBound = 0, upBound=0)
                  elif self.allocation[city][tpt]['state'] == AllocationState.LOCKED:
                     vars[tpt][city] = LpVariable(tpt+ "_"+city,cat="Integer", lowBound = int(self.allocation[city][tpt]['value']), upBound=int(self.allocation[city][tpt]['value']))
                  elif self.allocation[city][tpt]['state'] == AllocationState.DISABLED:
                     vars[tpt][city] = LpVariable(tpt+ "_"+city,cat="Integer", lowBound = 0, upBound=0)
      
      # The minimum objective function is added to 'prob' first
      prob += (
         lpSum([vars[tpt][city]*round(costs_dict[tpt][city],2) for (tpt, city) in Routes]),
         "Sum_of_Transporting_Costs",
      )

      # The supply maximum constraints are added to prob for each supply node (warehouses)
      for tpt in transporter:
         prob += (
               lpSum([vars[tpt][city] for city in destination]) == int(supply[tpt]),
               "Sum_of_Products_out_of_transporter_%s" % tpt,
         )
         prob += (
               lpSum([vars[tpt][city] for city in destination if city != dummyDestination]) >= self.minimumLoad[tpt],
               "Sum_of_Products_out_of_minimum_load_transporter_%s" % tpt,
         )

      # The demand minimum constraints are added to prob for each demand node (project)
      for city in destination:
         prob += (
               lpSum([vars[tpt][city] for tpt in transporter]) == int(demand[city]),
               "Sum_of_Products_into_destination%s" % city,
         )
      # The problem is solved using PuLP's choice of Solver
      status = prob.solve()
      if status == LpStatusOptimal:
         for city in destination:
            if city != dummyDestination:
               for tpt in transporter:
                  self.allocation[city][tpt]["value"] = int(vars[tpt][city].varValue)
         allocationCopy={}
         for city in self.allocation.keys():
            temp={}
            for tpt in self.allocation[city].keys():
               temp[tpt]={}
               temp[tpt]["value"]=self.allocation[city][tpt]["value"]
               temp[tpt]["state"]=self.allocation[city][tpt]["state"]
            allocationCopy[city]=temp
         self.allocationHistory.append((allocationCopy,value(prob.objective),self.carrierNumberBox.text()))
         self.updateAllocationTable()
         # self.allocationCostHistory.append(value(prob.objective))
         # print("                    :",end=" ")
         # for city in destination:
         #    print('{: >10}'.format(city),end=" ")
         # print()
         # for tpt in transporter:
         #    print('{: >20}:'.format(tpt),end=" ")
         #    for city in destination:
         #          print("{0:10d}".format(int(vars[tpt][city].varValue)),end=" ")
         #    print()
         # print("Value of Objective Function = ",value(prob.objective))
      else:
         for city in destination:
            if city != dummyDestination:
               for tpt in transporter:
                  self.allocation[city][tpt]["value"] = 0
                  if self.allocation[city][tpt]["state"] != AllocationState.DISABLED:
                     self.allocation[city][tpt]["state"]=AllocationState.RELEASE
         self.show_error_message("Infesible Solution! Ensure proper supply is available...")
         return


      self.optimalCost=value(prob.objective)
      self.costByTTA=self.getAllocatioCostUsingTTA()
      self.onCarrierChanged(self.carrierNumberBox.text())

   def getAllocatioCostUsingTTA(self):
    transporter = sorted(list(self.supply.keys()))  # List of transporters
    destination = sorted(list(self.demand.keys()))  # List of destinations
    supply = self.supply.copy()  # Copy supply to avoid modifying the original
    demand = self.demand.copy()  # Copy demand to avoid modifying the original
    ttaAllocation = dict()  # Allocation dictionary
    total_cost = 0  # Total transportation cost

    for city in destination:
        cityTransporter = []
        for tpt in transporter:
            if self.cost_matrix[tpt][city] != INFINITY:  # Only consider valid transporters
                cityTransporter.append(tpt)

        # Sort transporters by cost for the current city
        cityTransporter = sorted(cityTransporter, key=lambda x: self.cost_matrix[x][city])
        cityDemand = demand[city]
        ttaAllocation[city] = dict()  # Initialize allocation for the city

        for tpt in cityTransporter:
            if cityDemand > 0 and supply[tpt] > 0:  # Only allocate if demand and supply exist
                allocated_quantity = min(supply[tpt], cityDemand)  # Allocate as much as possible
                ttaAllocation[city][tpt] = allocated_quantity  # Record the allocation
                total_cost += (int(self.carrierNumberBox.text()) if self.carrierNumberBox.text() is not None else 1) * allocated_quantity * self.cost_matrix[tpt][city]

                # Update supply and demand
                supply[tpt] -= allocated_quantity
                cityDemand -= allocated_quantity

    # Debug outputs to validate the allocation
    print('ttaAllocation:', ttaAllocation)
    self.ttaAllocation = ttaAllocation
    self.ttaAllocationCost = total_cost

    # Verify allocations for cities
    for city in ttaAllocation.keys():
        print(f"City {city}: Total allocated = {sum(ttaAllocation[city].values())}, Demand = {self.demand[city]}")

    # Verify allocations for transporters
    for tpt in transporter:
        total_supply_used = sum(ttaAllocation[city].get(tpt, 0) for city in ttaAllocation.keys())
        print(f"Transporter {tpt}: Total supply used = {total_supply_used}, Supply = {self.supply[tpt]}")

    print('Total Cost:', total_cost)
    return total_cost

      
   def show_error_message(self,message,informativeMessage=None):
      error_message = QMessageBox()
      error_message.setIcon(QMessageBox.Critical)
      error_message.setText(message)
      if informativeMessage is not None:
         error_message.setInformativeText(informativeMessage)
      error_message.setWindowTitle('Error')
      error_message.exec_()
      
   def show_message(self,message,informativeMessage=None):
      message_box = QMessageBox()
      message_box.setIcon(QMessageBox.Information)
      message_box.setText(message)
      if informativeMessage is not None:
         message_box.setInformativeText(informativeMessage)
      message_box.setWindowTitle('Export Allocation')
      message_box.exec_()

class CategorySelector(QDialog):
   dialogClosed = pyqtSignal(list)
   def __init__(self,categories,label="Category Selector"):
      super().__init__()
      self.categories = categories
      self.labelFont = QFont("Helvetica", 10)
      self.setGeometry(0,0,500,600)
      qtRectangle = self.frameGeometry()
      centerPoint = QDesktopWidget().availableGeometry().center()
      qtRectangle.moveCenter(centerPoint)
      self.move(qtRectangle.topLeft())
      # self.setWindowTitle("HELLO!")

      selectorLayout = QVBoxLayout()

      self.selectorTable = QTableWidget()
      self.selectorTable.verticalHeader().setVisible(False)
      self.selectorTable.horizontalHeader().setVisible(False)
      self.selectorTable.setColumnCount(1)
      self.selectorTable.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
      for category in self.categories:
         currPos = self.selectorTable.rowCount()
         self.selectorTable.insertRow(currPos)
         checkbox = QCheckBox(category.value)
         checkbox.setChecked(category.isChecked)
         checkbox.setFont(self.labelFont)
         checkbox.stateChanged.connect(lambda state, category=category: self.onCheckboxChanged(state, category))
         checkbox.setStyleSheet("padding-left:10px")
         self.selectorTable.setCellWidget(currPos,0,checkbox)
      
      searchBoxLayout = QHBoxLayout()

      self.searchBox = QLineEdit()
      self.searchBox.setPlaceholderText("Search")
      self.searchBox.setFont(self.labelFont)
      self.searchBox.setStyleSheet('''
            QLineEdit {
               border:none;
            }
        ''')
      self.searchBox.textChanged.connect(self.onSearchTextChanged)
      searchBoxLayout.addWidget(self.searchBox)
      clearFont = QFont("Aharoni", 15)
      clearFont.setBold(True)
      self.searchClearBtn = QPushButton('X')
      self.searchClearBtn.setFont(clearFont)
      self.searchClearBtn.clicked.connect(self.onClearBtnClicked)
      searchBoxLayout.addWidget(self.searchClearBtn)
      searchWidget = QWidget()
      searchWidget.setLayout(searchBoxLayout)
      # searchWidget.setFixedHeight(40)
      searchWidget.setStyleSheet('''
            QWidget{
               border: 1px solid gray;
               border-radius: 10px;
               padding: 2px 10px;
               background:white;
            }pyinstaller
            QPushButton{
               border:1px solid gray;
               background: #f0f0f0;
               border-radius: 0;
            }
        ''')
      # self.searchClearBtn.setStyleSheet('''
      #    ''')
      selectorLayout.addWidget(searchWidget)

      selectorLayout.addWidget(self.selectorTable)
      self.okBtn = QPushButton('OK')
      self.okBtn.clicked.connect(self.onOkClicked)
      self.okBtn.setFixedSize(100,40)
      selectorLayout.addWidget(self.okBtn,alignment=Qt.AlignRight)
      self.setLayout(selectorLayout)
      
   def onClearBtnClicked(self):
      self.searchBox.setText("")

   def onCheckboxChanged(self,state,category):
      category.isChecked = state == Qt.Checked

   def onOkClicked(self):
      self.dialogClosed.emit(self.categories)
      self.close()
   
   def onSearchTextChanged(self,text):
      regex_pattern = r'^{}.*'.format(re.escape(text))
      regex = re.compile(regex_pattern, re.IGNORECASE)
      for i in range(self.selectorTable.rowCount()):
         item = self.selectorTable.cellWidget(i, 0)  
         if item:
            category = item.text()
            match = regex.match(category)
            self.selectorTable.setRowHidden(i, match is None)
   
class AllocationState(Enum):
   RELEASE = 1
   BLOCKED = 2
   LOCKED = 3
   DISABLED = 4
   
class Category:
   def __init__(self):
      self.value=""
      self.isChecked = False
      
   def __init__(self,value,isChecked=False):
      self.value=value
      self.isChecked = isChecked



def main():
   app = QApplication(sys.argv)
   custom_font = QFont()
   custom_font.setWeight(32)
   # QApplication.setFont(custom_font, "QLabel")
   # QApplication.setFont(custom_font, "QTextEdit")
   # app.setStyleSheet('.QLabel { font-size: 10pt;}')
   ex = transportAllocator()
   ex.show()
   sys.exit(app.exec_())
	
if __name__ == '__main__':
   main()