# Transportation Cost Optimizer — Demo Script

> **Purpose:** Step-by-step demo script for client presentations.
> Read this document while demonstrating the tool live.
>
> **Files:** All scenarios use the same 3 files from the `demo_files/` folder.
> Also share `Comparison.xlsx` — a pre-built Excel with formula-based cost breakdowns for each scenario.
> To regenerate all files: `python demo_files/create_demo_files.py`

---

## The Dataset at a Glance

**4 transporters, 3 destinations, 1 set of files — 9 scenarios.**

### Cost per Unit (Cost.xlsx — 12 routes)

| Transporter | Chennai (South) | Coimbatore (South) | Hyderabad (Central) |
|-------------|:---:|:---:|:---:|
| **ALPHA**   | 13  | **7**  | 20 |
| **BETA**    | 14  | 15  | **8** |
| **GAMMA**   | 16  | 18  | 18 |
| **DELTA**   | 18  | 20  | 12 |

> ALPHA is cheapest for both Chennai (13) and Coimbatore (7) — this is key to Scenario 1.

### Demand (Demand.xlsx)

| Destination | Demand |
|---|:---:|
| Chennai     | 30 |
| Coimbatore  | 25 |
| Hyderabad   | 25 |
| **Total**   | **80** |

### Supply (Supply.xlsx — regional caps)

| Transporter | South | Central | Total |
|---|:---:|:---:|:---:|
| ALPHA  | 35 |  0 | 35 |
| BETA   | 15 | 25 | 40 |
| GAMMA  | 20 | 10 | 30 |
| DELTA  | 10 | 15 | 25 |
| **Total** | **80** | **50** | **130** |

> Supply (130) > Demand (80). Surplus is absorbed automatically.
> North, East, West columns are all 0 (no destinations in those regions).

### Pre-verified Costs

| Scenario | Cost | vs Optimal |
|---|:---:|:---:|
| Super Optimal (no constraints) | **795** | — |
| Manual greedy (human approach) | **940** | +18.2% |
| Min Load DELTA=10 | **825** | +3.8% |
| Block ALPHA to Coimbatore | **995** | +25.2% |
| Lock ALPHA to Chennai = 25 | **900** | +13.2% |

### Comparison Excel (Comparison.xlsx)

Pre-built Excel file with **5 sheets**, each containing formula-based cost calculations:

| Sheet | What It Shows |
|---|---|
| **Greedy vs Optimal** | Side-by-side: manual allocation (940) vs optimizer (795) with route-cost formulas |
| **Min Load Impact** | Without vs with DELTA min load = 10, extra cost calculated |
| **Block Route Impact** | Optimal vs blocked ALPHA→Coimbatore, disruption cost quantified |
| **Lock Route Impact** | Optimal vs locked ALPHA→Chennai=25, override cost quantified |
| **Summary** | All scenarios in one table with cost, % increase, and key insight |

> Open this file during the demo to show clients the math behind each scenario. All cost cells use formulas — change any allocation value and the totals update automatically.

---

## Scenario 1: Why Optimization Beats Intuition

### Pitch Story

> *"Your team manually assigns shipments by picking the cheapest transporter for each destination. Seems logical — but let me show you what the optimizer finds."*

### The Manual (Greedy) Approach — Walk Through It on a Whiteboard

| Step | Destination | Cheapest | Qty | Cap Left | Cost |
|:---:|---|---|:---:|:---:|---:|
| 1 | Chennai | ALPHA (13/unit) | 30 | ALPHA South: 35→5 | 390 |
| 2 | Coimbatore | ALPHA (7/unit) | 5 | ALPHA South: 5→0 | 35 |
|   | Coimbatore | BETA (15/unit) | 15 | BETA South: 15→0 | 225 |
|   | Coimbatore | GAMMA (18/unit) | 5 | — | 90 |
| 3 | Hyderabad | BETA (8/unit) | 25 | BETA Central: 25→0 | 200 |
| | | | | **Manual Total** | **940** |

> *"Step 2 is where it breaks. ALPHA was the cheapest for Coimbatore at 7/unit — but we used up all of ALPHA's South capacity on Chennai. Now Coimbatore costs 15–18/unit from other transporters."*

### Demo Steps

1. Upload all three files from `demo_files/` → Click **Load Files**
2. Select all destinations and transporters
3. Set all **Min Load** to **0**
4. Click **Allocate**

### What the Client Sees

The optimizer produces **cost 795** — the tool saved **145 (15.4%)** vs the manual approach.

**Why?** The optimizer only sends 10 units from ALPHA to Chennai (not 30) and sends 25 to Coimbatore instead. It "sacrifices" 1/unit on Chennai (13→14 from BETA) to save 8/unit on Coimbatore (7 vs 15). This global trade-off is invisible to a human working destination-by-destination.

| Route | Manual | Optimizer |
|---|:---:|:---:|
| ALPHA → Chennai | 30 | 10 |
| ALPHA → Coimbatore | 5 | 25 |
| BETA → Chennai | 0 | 15 |
| GAMMA → Chennai | 0 | 5 |
| BETA → Coimbatore | 15 | 0 |
| GAMMA → Coimbatore | 5 | 0 |

> *"With real data — 50 transporters, 30 destinations — this kind of trade-off is impossible to spot manually. The optimizer handles it in under a second."*
>
> **Show the client:** Open `Comparison.xlsx` → **Greedy vs Optimal** sheet. The formulas prove the math.

---

## Scenario 2: Basic Allocation Walkthrough

### Pitch Story

> *"Let me walk you through the basic workflow — upload, optimize, review."*

### Demo Steps

1. Open the tool — you land on the **Configuration** page
2. Upload **Cost.xlsx** → **Demand.xlsx** → **Supply.xlsx** from `demo_files/`
3. Click **Load Files** — success message appears
4. Verify the setup:
   - **Destinations:** Chennai, Coimbatore, Hyderabad with demand values
   - **Transporters:** ALPHA, BETA, GAMMA, DELTA with supply values
   - **Balance:** Supply - Demand = +50 (surplus handled automatically)
5. Keep all Min Load at **0**
6. Click **Allocate**

### What to Point Out

- The **Allocation Matrix** shows units shipped per route
- Cell colours: **Green** = solver decided freely, **Grey** = no route
- **Super Optimal** = **Optimal** = **795** (both equal because Min Load = 0)
- The **bar chart** shows one green bar (Optimal) and one blue bar (Super Optimal) — both at the same height

> *"This is your mathematically cheapest shipping plan. Every green cell was chosen by the optimizer to minimize total cost."*

---

## Scenario 3: Super Optimal vs Optimal

### Pitch Story

> *"Your contracts require each transporter to ship a minimum quantity. How much does that constraint cost you? The tool quantifies it exactly."*

### Part A — No Minimum Load (costs are equal)

1. Start from the allocation result (Scenario 2)
2. Point out: **Super Optimal = Optimal = 795**

> *"When there are no minimum load rules, the solver has full freedom. Both benchmarks are identical."*

### Part B — Add Minimum Load (costs diverge)

1. Click **Back** to return to Configuration
2. Set **Min Load** for **DELTA** to **10**
3. Click **Allocate**
4. Observe: **Super Optimal = 795** (unchanged), **Optimal = 825** (+3.8%)

### What to Explain

> *"Super Optimal is the theoretical best — if every transporter could ship zero. Optimal is the best achievable plan given your minimum load rules. The gap (3.8% here) is exactly what your business constraints cost. You can now decide: is that constraint worth 30 in added cost?"*

| Metric | No Min Load | DELTA Min Load = 10 |
|---|:---:|:---:|
| Super Optimal | 795 | 795 (unchanged) |
| Optimal | 795 | 825 |
| Gap | 0% | +3.8% |

> **Show the client:** Open `Comparison.xlsx` → **Min Load Impact** sheet.

---

## Scenario 4: Minimum Load Constraints

### Pitch Story

> *"DELTA has a contract requiring them to carry at least 10 units. Let's see how the optimizer adapts."*

### Demo Steps

1. From Configuration, set **Min Load** for **DELTA** to **10**
2. Leave ALPHA, BETA, GAMMA at **0**
3. Click **Allocate**
4. In the matrix, observe that DELTA now ships 10 units to Chennai

### What to Explain

- Without the constraint, DELTA shipped **0** (all to dummy) — optimizer ignored the most expensive transporter
- With Min Load = 10, DELTA ships to its cheapest destination (**Chennai at 18/unit**)
- Cost increased by **30** (from 795 to 825) — the optimizer found the cheapest way to honour the contract

> *"The optimizer doesn't just blindly add 10 units from DELTA — it picks DELTA's cheapest route and re-optimizes everything else around it."*

---

## Scenario 5: Manual Matrix Editing

### Pitch Story

> *"Your warehouse manager says Chennai must receive exactly 15 units from ALPHA — there is a standing agreement. Let's set that manually."*

### Demo Steps

1. Run a normal allocation first (Scenario 2, Min Load all 0)
2. In the **Allocation Matrix**, click the cell at **Chennai x ALPHA**
3. Type **15** and click elsewhere (or press Enter)
4. The cell turns **yellow (Locked)** automatically
5. Below the matrix: **Selected: Chennai → ALPHA | State: LOCKED**
6. The **Re-Allocate** button is now active

### What to Explain

> *"Any value you type into a cell automatically locks it. The optimizer will treat that as a fixed constraint — it cannot change the locked value. The Re-Allocate button lets you re-optimize everything else around your manual entry."*

---

## Scenario 6: Lock Feature

### Pitch Story

> *"Management decides ALPHA must deliver exactly 25 units to Chennai. Lock it and see the cost impact."*

### Demo Steps

1. Start from a fresh allocation (Scenario 2)
2. Click the cell **Chennai x ALPHA**
3. Type **25** — cell auto-locks (turns yellow)
4. Click **Re-Allocate**
5. Observe the results:

| What to Check | Expected |
|---|---|
| Chennai x ALPHA | 25 (yellow, locked) |
| Other cells | Re-optimized (green) |
| Allocation Cost | **900** |
| Delta vs Optimal | **+13.2%** |

### What to Explain

The optimizer wanted ALPHA to send only 10 to Chennai. Forcing 25 means:
- ALPHA has only 10 South capacity left for Coimbatore (instead of 25)
- Coimbatore must get 15 units from BETA at 15/unit (instead of ALPHA at 7/unit)
- That costs an extra **105** per cycle

> *"The delta tells you exactly how much this management decision costs. You can now have a data-driven conversation: is this constraint worth +13.2%?"*
>
> **Show the client:** Open `Comparison.xlsx` → **Lock Route Impact** sheet.

---

## Scenario 7: Block Route Feature

### Pitch Story

> *"The route from ALPHA to Coimbatore is temporarily unavailable — a warehouse closure, a contract dispute, whatever the reason. Block it and see the impact."*

### Demo Steps

1. Start from a fresh allocation (Scenario 2)
2. Click the cell **Coimbatore x ALPHA**
3. Click the **Block** button below the matrix
4. The cell turns **red**, value becomes **0**
5. Click **Re-Allocate**
6. Observe:

| What to Check | Expected |
|---|---|
| Coimbatore x ALPHA | 0 (red, blocked) |
| ALPHA → Chennai | Increases (ALPHA redirected) |
| Coimbatore served by | BETA (15) + GAMMA (10) |
| Allocation Cost | **995** |
| Delta vs Optimal | **+25.2%** |

### What to Explain

> *"Blocking ALPHA to Coimbatore costs +200 per cycle (+25.2%). That is because ALPHA was the cheapest route to Coimbatore at 7/unit — now Coimbatore must use BETA at 15/unit and GAMMA at 18/unit. If this is a contract dispute, you now know the negotiation ceiling: resolving it saves 200 per cycle."*

> **Show the client:** Open `Comparison.xlsx` → **Block Route Impact** sheet.

### Releasing the Block

1. Click the **red** Coimbatore x ALPHA cell
2. Click **Release** — cell turns green
3. Click **Re-Allocate** — cost drops back to **795**

> *"Releasing the constraint immediately restores the optimal plan."*

---

## Scenario 8: Multi-Step Reallocation

### Pitch Story

> *"Let's simulate a real planning session with multiple changes, step by step."*

### Demo Steps

1. **Start fresh:** Run Scenario 2 (all constraints off, cost = 795)

2. **Iteration 1 — Lock a route:**
   - Click **Coimbatore x BETA**, type **10**, it auto-locks (yellow)
   - Click **Re-Allocate**
   - Note the new **Allocation Cost** and the **Iteration Summary** table

3. **Iteration 2 — Block a route:**
   - Click **Chennai x GAMMA**
   - Click **Block** (red, value → 0)
   - Click **Re-Allocate**
   - Cost rises further — two constraints now active

4. **Iteration 3 — Release the block:**
   - Click the red **Chennai x GAMMA** cell
   - Click **Release** (green)
   - Click **Re-Allocate**
   - Cost drops back — only the lock remains

### What to Show

The **Iteration Summary table** tracks every version:

| Iteration | Allocation Cost | Trend |
|---|:---:|---|
| Optimal | 795 | Baseline |
| Allocation 1 (lock Coimbatore x BETA=10) | Higher | Lock adds cost |
| Allocation 2 (+ block Chennai x GAMMA) | Higher still | Block adds more cost |
| Allocation 3 (release block) | Drops back | Releasing removes that cost |

> *"Every decision is tracked. You can compare all iterations and pick the plan with the best cost-constraint trade-off."*

---

## Scenario 9: Reading the Bar Chart

### Pitch Story

> *"The bar chart gives you an instant visual summary across all iterations."*

### Demo Steps

1. Complete Scenario 8 (3 iterations)
2. Scroll to the bar chart

### How to Read It

| Bar | Colour | Meaning |
|---|---|---|
| Super Optimal | Blue | Theoretical floor — no constraints |
| Optimal | Green | Best with min load constraints |
| Allocation 1, 2, 3... | Amber | Cost after each manual change |

### Key Points to Highlight

- **Blue bar is the floor** — you can never go below it
- **Green bar is the realistic best** — includes minimum load rules
- **Amber bars go UP** from green — every lock/block adds cost
- **Releasing constraints brings bars back DOWN** toward green
- The **gap between blue and green** = cost of minimum load requirements
- The **gap between green and amber** = cost of your manual decisions

> *"If an amber bar is close to green, your adjustments are cheap — keep them. If it is much taller, consider relaxing some constraints."*

---

## Quick Reference

### Cell Colours

| Colour | State | Meaning |
|---|---|---|
| Green | Released | Solver decides freely |
| Yellow | Locked | Fixed by user — solver cannot change |
| Red | Blocked | Route unavailable — forced to 0 |
| Grey | Disabled | No route exists in cost file |

### Workflow

```
Upload 3 files → Load → Select routes → Set Min Load → Allocate
    |
    v
Review matrix → Edit / Lock / Block cells → Re-Allocate
    |
    v
Compare iterations (table + chart) → Export to Excel
```

### Number of Carriers

The "Number of Carriers" input at the top of the allocation page multiplies all costs. Use it to show total fleet cost:
- 1 carrier: per-vehicle cost
- 100 carriers: fleet-wide cost

---

## Presenter Playbook

### Recommended Flow (15-minute demo)

| Time | Scenario | Key Message |
|---|---|---|
| 0–3 min | **Scenario 1** | Hook: optimizer beats intuition by 15% |
| 3–5 min | **Scenario 2** | Basic workflow: upload → allocate → review |
| 5–7 min | **Scenario 3** | Two benchmarks: Super Optimal vs Optimal |
| 7–9 min | **Scenario 6** | Lock: fix a route, see the cost impact |
| 9–11 min | **Scenario 7** | Block: remove a route, see the cost impact |
| 11–13 min | **Scenario 8** | Multi-step: show iteration tracking |
| 13–15 min | **Scenario 9** | Chart: visual summary of all decisions |

### Tips

1. **Start with Scenario 1** — the cost saving hooks the audience
2. **Open Comparison.xlsx** alongside the tool during the demo — show the formulas to prove the math
3. **Let the client suggest** which cell to lock or block in Scenarios 6–7
4. **End with the chart** — it makes the value proposition visual
5. **Mention scale**: *"This is 4 transporters. Imagine 50 transporters and 30 destinations — the optimizer handles it the same way, in under a second."*
6. **Export**: Click "Export to Excel" to show that the full plan is downloadable

### Common Client Questions

| Question | Answer |
|---|---|
| "How fast is it?" | Under 1 second for typical datasets (50 transporters, 30 destinations) |
| "Can I override the optimizer?" | Yes — lock any cell to fix a value, block any route to remove it |
| "What if my constraints make it infeasible?" | The tool tells you immediately and suggests relaxing constraints |
| "Can I compare scenarios?" | Yes — the iteration table and bar chart track every version |
| "What does the surplus go to?" | Surplus supply is automatically absorbed — no waste in the plan |
