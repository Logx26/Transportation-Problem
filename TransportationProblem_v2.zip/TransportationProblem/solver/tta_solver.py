import logging
from utils.constants import INFINITY

logger = logging.getLogger(__name__)


def solve_tta(
    supply: dict,
    demand: dict,
    cost_matrix: dict,
    carrier_number: int = 1,
) -> tuple[dict, float]:
    """Solve transportation problem using greedy TTA (Time-Table Allocation) baseline.

    Allocates from cheapest transporter first for each destination.
    Used as a benchmark to compare against the optimal LP solution.

    Args:
        supply: {transporter: quantity}
        demand: {destination: quantity}
        cost_matrix: {transporter: {destination: cost}}
        carrier_number: multiplier for total cost

    Returns:
        (tta_allocation, total_cost)
        tta_allocation: {destination: {transporter: quantity}}
    """
    transporter = sorted(list(supply.keys()))
    destination = sorted(list(demand.keys()))
    supply_remaining = supply.copy()
    demand_remaining = demand.copy()
    tta_allocation: dict = {}
    total_cost = 0.0

    for city in destination:
        # Collect valid transporters for this city (non-infinite cost)
        city_transporters = [
            tpt for tpt in transporter
            if cost_matrix[tpt].get(city, INFINITY) != INFINITY
        ]
        # Sort by cost ascending (cheapest first)
        city_transporters.sort(key=lambda t: cost_matrix[t][city])

        city_demand = demand_remaining[city]
        tta_allocation[city] = {}

        for tpt in city_transporters:
            if city_demand <= 0 or supply_remaining[tpt] <= 0:
                continue
            allocated = min(supply_remaining[tpt], city_demand)
            tta_allocation[city][tpt] = allocated
            total_cost += carrier_number * allocated * cost_matrix[tpt][city]
            supply_remaining[tpt] -= allocated
            city_demand -= allocated

    logger.info(
        "TTA solved. Total cost (x%d carriers): %s", carrier_number, total_cost
    )
    for city in tta_allocation:
        allocated_total = sum(tta_allocation[city].values())
        logger.debug(
            "City %s: allocated=%d, demand=%d", city, allocated_total, demand[city]
        )
    for tpt in transporter:
        used = sum(tta_allocation[city].get(tpt, 0) for city in tta_allocation)
        logger.debug(
            "Transporter %s: used=%d, supply=%d", tpt, used, supply[tpt]
        )

    return tta_allocation, total_cost
