import logging
from pulp import LpProblem, LpMinimize, LpVariable, lpSum, LpStatusOptimal, value

from models.enums import AllocationState
from utils.constants import INFINITY

logger = logging.getLogger(__name__)


def solve_lp(
    supply: dict,
    demand: dict,
    cost_matrix: dict,
    allocation: dict,
    min_load: dict,
    regional_supply: dict,
    destination_region: dict,
) -> tuple[dict, float, str]:
    """Solve the transportation problem using PuLP MILP with region-constrained supply.

    Each transporter's supply for a region may only be used for destinations
    in that same region. The dummy destination (used to absorb supply surplus)
    is not region-constrained.

    Args:
        supply:             {transporter: total_quantity}
        demand:             {destination: quantity}
        cost_matrix:        {transporter: {destination: cost}}
        allocation:         {destination: {transporter: {"value": int, "state": AllocationState}}}
        min_load:           {transporter: minimum_quantity}
        regional_supply:    {transporter: {"North": n, "South": s, "East": e, "West": w, "Central": c}}
        destination_region: {destination: region_name}

    Returns:
        (updated_allocation, optimal_cost, status)
        status is "optimal" or "infeasible"
    """
    supply = supply.copy()
    demand = demand.copy()
    costs_dict = {tpt: cost_matrix[tpt].copy() for tpt in cost_matrix}

    transporter = sorted(list(supply.keys()))
    destination = sorted(list(demand.keys()))

    dummy = "zzz_dummydestination"
    if sum(supply.values()) != sum(demand.values()):
        demand[dummy] = abs(sum(supply.values()) - sum(demand.values()))
        destination.append(dummy)
        for tpt in transporter:
            costs_dict[tpt][dummy] = 0

    # Mark DISABLED routes (infinite cost)
    for city in destination:
        if city == dummy:
            continue
        for tpt in transporter:
            if costs_dict[tpt].get(city, INFINITY) == INFINITY:
                allocation[city][tpt]["state"] = AllocationState.DISABLED

    prob = LpProblem("Material_Supply_Problem", LpMinimize)
    routes = [(tpt, city) for tpt in transporter for city in destination]

    # Build LP variables with state-based bounds
    vars_dict: dict = {}
    for tpt in transporter:
        vars_dict[tpt] = {}
        for city in destination:
            var_name = f"{tpt}_{city}".replace(" ", "_")
            if city == dummy:
                vars_dict[tpt][city] = LpVariable(var_name, cat="Integer", lowBound=0)
            else:
                state = allocation[city][tpt]["state"]
                if state == AllocationState.RELEASE:
                    vars_dict[tpt][city] = LpVariable(var_name, cat="Integer", lowBound=0)
                elif state == AllocationState.BLOCKED:
                    vars_dict[tpt][city] = LpVariable(var_name, cat="Integer", lowBound=0, upBound=0)
                elif state == AllocationState.LOCKED:
                    locked_val = int(allocation[city][tpt]["value"])
                    vars_dict[tpt][city] = LpVariable(var_name, cat="Integer", lowBound=locked_val, upBound=locked_val)
                else:  # DISABLED
                    vars_dict[tpt][city] = LpVariable(var_name, cat="Integer", lowBound=0, upBound=0)

    # Objective: minimise total transport cost
    prob += (
        lpSum([vars_dict[tpt][city] * round(costs_dict[tpt][city], 2) for (tpt, city) in routes]),
        "Sum_of_Transporting_Costs",
    )

    # ── Supply constraints ────────────────────────────────────────────────────

    # Pre-compute: group real destinations by region for region cap constraints
    region_dest_map: dict = {}
    for city in destination:
        if city == dummy:
            continue
        reg = destination_region.get(city)
        if reg:
            region_dest_map.setdefault(reg, []).append(city)

    for tpt in transporter:
        # Total supply equality (dummy absorbs any surplus)
        prob += (
            lpSum([vars_dict[tpt][city] for city in destination]) == int(supply[tpt]),
            f"TotalSupply_{tpt}",
        )

        # Minimum load constraint (excluding dummy)
        prob += (
            lpSum([vars_dict[tpt][city] for city in destination if city != dummy])
            >= min_load.get(tpt, 0),
            f"MinLoad_{tpt}",
        )

        # Region-constrained supply:
        # For each region R: sum of T's allocations to destinations in R ≤ T's R supply cap
        reg_supply = regional_supply.get(tpt, {})
        for reg, reg_cap in reg_supply.items():
            dests_in_region = region_dest_map.get(reg, [])
            if dests_in_region:
                prob += (
                    lpSum([vars_dict[tpt][city] for city in dests_in_region])
                    <= int(reg_cap),
                    f"RegionCap_{tpt}_{reg}".replace(" ", "_"),
                )

    # ── Demand constraints ────────────────────────────────────────────────────
    for city in destination:
        prob += (
            lpSum([vars_dict[tpt][city] for tpt in transporter]) == int(demand[city]),
            f"Demand_{city}".replace(" ", "_"),
        )

    # ── Solve ─────────────────────────────────────────────────────────────────
    status = prob.solve()

    if status == LpStatusOptimal:
        for city in destination:
            if city != dummy:
                for tpt in transporter:
                    allocation[city][tpt]["value"] = int(vars_dict[tpt][city].varValue)
        optimal_cost = value(prob.objective)
        logger.info("LP solved optimally. Cost: %s", optimal_cost)
        return allocation, optimal_cost, "optimal"
    else:
        for city in destination:
            if city != dummy:
                for tpt in transporter:
                    allocation[city][tpt]["value"] = 0
                    if allocation[city][tpt]["state"] != AllocationState.DISABLED:
                        allocation[city][tpt]["state"] = AllocationState.RELEASE
        logger.warning("LP infeasible. Status: %s", status)
        return allocation, 0.0, "infeasible"
