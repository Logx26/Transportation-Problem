"""
Generate mock input files that match the Transport Allocator format.

Run from the project root or input_files/ directory:
    python input_files/create_mock_files.py

Files produced (in input_files/):
    Cost.xlsx    — Transporter, Destination, Region, Car
    Demand.xlsx  — Destination, Demand  (one row per city)
    Supply.xlsx  — Transporter, North, South, East, West, Central
"""

import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl import Workbook

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Shared mock data ──────────────────────────────────────────────────────────

TRANSPORTERS = [
    "ALPHA LOGISTICS",
    "BETA CARRIERS",
    "GAMMA TRANSPORT",
    "DELTA MOVERS",
    "EPSILON FREIGHT",
]

# Destinations and their regions
DESTINATIONS = {
    "Chennai":   "South",
    "Trichy":    "South",
    "Delhi":     "North",
    "Lucknow":   "North",
    "Hyderabad": "Central",
    "Nagpur":    "Central",
}

# Cost matrix (INR per unit car).
# None = route not available (treated as DISABLED in the app).
#
#                        Chennai  Trichy  Delhi  Lucknow  Hyderabad  Nagpur
COST_MATRIX = {
    "ALPHA LOGISTICS":  [ 1400,   1200,   2800,   2600,    1900,      None  ],
    "BETA CARRIERS":    [ 1500,   1300,   2700,   None,    2000,      1800  ],
    "GAMMA TRANSPORT":  [ None,   1100,   2900,   2500,    None,      1900  ],
    "DELTA MOVERS":     [ 1600,   None,   None,   2700,    1800,      1700  ],
    "EPSILON FREIGHT":  [ 1450,   1250,   2750,   2650,    1950,      1850  ],
}

# Regional supply per transporter (units per region).
# Total supply for each transporter = sum of all 5 region columns.
#                         North  South  East  West  Central
REGIONAL_SUPPLY = {
    "ALPHA LOGISTICS":  ( 200,   300,   0,    0,    150  ),  # total 650
    "BETA CARRIERS":    ( 180,   250,   0,    0,    120  ),  # total 550
    "GAMMA TRANSPORT":  ( 220,   280,   0,    0,     0   ),  # total 500 (no Central)
    "DELTA MOVERS":     (   0,   200,   0,    0,    180  ),  # total 380 (no North)
    "EPSILON FREIGHT":  ( 160,   240,   0,    0,    100  ),  # total 500
}

# Demand per destination
DEMAND = {
    "Chennai":   350,
    "Trichy":    280,
    "Delhi":     300,
    "Lucknow":   260,
    "Hyderabad": 200,
    "Nagpur":    180,
}


# ── Cost File ─────────────────────────────────────────────────────────────────

def create_cost_file():
    wb = Workbook()
    ws = wb.active
    ws.title = "Cost"

    header_font  = Font(bold=True, color="FFFFFF")
    header_fill  = PatternFill("solid", fgColor="1F4E79")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ["Transporter", "Destination", "Region", "Car"]
    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = header_align

    row = 2
    dest_list = list(DESTINATIONS.keys())
    for tpt in TRANSPORTERS:
        for dest_idx, dest in enumerate(dest_list):
            cost = COST_MATRIX[tpt][dest_idx]
            if cost is not None:
                ws.cell(row=row, column=1, value=tpt)
                ws.cell(row=row, column=2, value=dest)
                ws.cell(row=row, column=3, value=DESTINATIONS[dest])
                ws.cell(row=row, column=4, value=cost)
                row += 1

    for col_letter, width in zip("ABCD", [25, 16, 12, 14]):
        ws.column_dimensions[col_letter].width = width

    path = os.path.join(OUTPUT_DIR, "Cost.xlsx")
    wb.save(path)
    print(f"Created: {path}  ({row - 2} route rows)")


# ── Demand File ───────────────────────────────────────────────────────────────

def create_demand_file():
    wb = Workbook()
    ws = wb.active
    ws.title = "Demand"

    header_font  = Font(bold=True, color="FFFFFF")
    header_fill  = PatternFill("solid", fgColor="375623")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, h in enumerate(["Destination", "Demand"], start=1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = header_align

    for row, (dest, qty) in enumerate(DEMAND.items(), start=2):
        ws.cell(row=row, column=1, value=dest)
        ws.cell(row=row, column=2, value=qty)

    ws.column_dimensions["A"].width = 18
    ws.column_dimensions["B"].width = 12

    path = os.path.join(OUTPUT_DIR, "Demand.xlsx")
    wb.save(path)
    print(f"Created: {path}  (total demand: {sum(DEMAND.values())})")


# ── Supply File ───────────────────────────────────────────────────────────────

def create_supply_file():
    wb = Workbook()
    ws = wb.active
    ws.title = "Supply"

    header_font  = Font(bold=True, color="FFFFFF")
    header_fill  = PatternFill("solid", fgColor="7B2C2C")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ["Transporter", "North", "South", "East", "West", "Central"]
    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = header_align

    for row, tpt in enumerate(TRANSPORTERS, start=2):
        north, south, east, west, central = REGIONAL_SUPPLY[tpt]
        ws.cell(row=row, column=1, value=tpt)
        ws.cell(row=row, column=2, value=north)
        ws.cell(row=row, column=3, value=south)
        ws.cell(row=row, column=4, value=east)
        ws.cell(row=row, column=5, value=west)
        ws.cell(row=row, column=6, value=central)

    for col_letter, width in zip("ABCDEF", [25, 10, 10, 10, 10, 12]):
        ws.column_dimensions[col_letter].width = width

    path = os.path.join(OUTPUT_DIR, "Supply.xlsx")
    wb.save(path)

    print(f"Created: {path}")
    print("  Regional supply per transporter:")
    for tpt in TRANSPORTERS:
        n, s, e, w, c = REGIONAL_SUPPLY[tpt]
        print(f"    {tpt}: N={n} S={s} E={e} W={w} C={c} -> Total={n+s+e+w+c}")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Generating mock input files...\n")
    create_cost_file()
    create_demand_file()
    create_supply_file()
    total_supply = sum(sum(v) for v in REGIONAL_SUPPLY.values())
    total_demand = sum(DEMAND.values())
    print(f"\nSupply vs Demand:")
    print(f"  Total supply : {total_supply}")
    print(f"  Total demand : {total_demand}")
    print(f"  Balance      : {total_supply - total_demand:+d}  (surplus -> dummy destination)")
    print(f"\nDone. Files saved to: {OUTPUT_DIR}")
