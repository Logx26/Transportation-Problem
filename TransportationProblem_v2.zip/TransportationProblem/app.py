import streamlit as st

from ui.state import init_session_state
from ui.pages.setup_page import render_setup_page
from ui.pages.allocation_page import render_allocation_page

st.set_page_config(
    page_title="Cost Optimizer",
    page_icon="🚚",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Global CSS & Header ───────────────────────────────────────────────────────
st.markdown("""
<style>
/* ── Google Font ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* ── Hide default Streamlit header/footer ── */
#MainMenu, footer, header { visibility: hidden; }

/* ── Top header bar ── */
.co-header {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    padding: 14px 32px;
    margin: -1rem -1rem 1.5rem -1rem;
    display: flex;
    align-items: center;
    gap: 14px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.3);
}
.co-header .co-icon {
    font-size: 28px;
}
.co-header .co-title {
    font-size: 22px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: 0.5px;
}
.co-header .co-subtitle {
    font-size: 12px;
    color: #a0aec0;
    margin-top: 2px;
}

/* ── Metric cards ── */
[data-testid="metric-container"] {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 14px 18px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
[data-testid="metric-container"] label {
    font-size: 12px !important;
    font-weight: 600 !important;
    color: #64748b !important;
    text-transform: uppercase;
    letter-spacing: 0.6px;
}
[data-testid="metric-container"] [data-testid="stMetricValue"] {
    font-size: 22px !important;
    font-weight: 700 !important;
    color: #1e293b !important;
}

/* ── Primary buttons ── */
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #0f3460, #16213e);
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    padding: 10px 20px;
    letter-spacing: 0.3px;
    transition: opacity 0.15s;
}
.stButton > button[kind="primary"]:hover {
    opacity: 0.88;
}

/* ── Secondary buttons ── */
.stButton > button[kind="secondary"] {
    border-radius: 8px;
    font-weight: 500;
}

/* ── Section headers ── */
h1 { color: #1e293b !important; font-weight: 700 !important; font-size: 1.7rem !important; }
h2 { color: #1e293b !important; font-weight: 600 !important; }
h3 { color: #334155 !important; font-weight: 600 !important; }
h4 { color: #475569 !important; font-weight: 600 !important; }

/* ── Info / warning / error boxes ── */
[data-testid="stAlert"] {
    border-radius: 8px;
}

/* ── Dataframe ── */
[data-testid="stDataFrame"] {
    border-radius: 8px;
    overflow: hidden;
}

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: #f1f5f9;
    border-right: 1px solid #e2e8f0;
}
[data-testid="stSidebar"] .stButton > button {
    border-radius: 8px;
    font-size: 13px;
}

/* ── Number input ── */
[data-testid="stNumberInput"] input {
    border-radius: 8px;
    border: 1px solid #cbd5e1;
}

/* ── Selectbox / multiselect ── */
[data-testid="stSelectbox"] > div > div,
[data-testid="stMultiSelect"] > div > div {
    border-radius: 8px !important;
}

/* ── File uploader ── */
[data-testid="stFileUploader"] {
    border-radius: 10px;
}

/* ── Download button ── */
.stDownloadButton > button {
    border-radius: 8px;
    font-weight: 600;
}

/* ── Divider ── */
hr {
    border-color: #e2e8f0;
    margin: 1rem 0;
}

/* ── Caption text ── */
.stCaption {
    color: #64748b;
    font-size: 12px;
}
</style>

<div class="co-header">
    <span class="co-icon">🚚</span>
    <div>
        <div class="co-title">Cost Optimizer</div>
        <div class="co-subtitle">Transportation Allocation & Route Optimization</div>
    </div>
</div>
""", unsafe_allow_html=True)

init_session_state()

if st.session_state.page == "setup":
    render_setup_page()
else:
    render_allocation_page()
