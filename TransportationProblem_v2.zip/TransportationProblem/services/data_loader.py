import logging
import os
import tempfile

import duckdb

from models.data_models import Category
from utils.constants import INFINITY

logger = logging.getLogger(__name__)

_DUCKDB_SPATIAL_LOADED = False
REGION_COLS = ["North", "South", "East", "West", "Central"]


def _ensure_spatial_extension():
    global _DUCKDB_SPATIAL_LOADED
    if not _DUCKDB_SPATIAL_LOADED:
        duckdb.install_extension("spatial")
        duckdb.load_extension("spatial")
        _DUCKDB_SPATIAL_LOADED = True


def _write_temp_file(file_bytes: bytes, suffix: str = ".xlsx") -> str:
    """Write bytes to a named temp file and return its path."""
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(file_bytes)
    tmp.flush()
    tmp.close()
    return tmp.name


def load_cost_file(
    file_bytes: bytes,
) -> tuple[list[Category], list[Category], dict, dict, dict]:
    """Load cost file.

    Expected columns: Transporter, Destination, Region, Car

    Returns:
        (transporters, destinations, region_map, cost_matrix, destination_region)
        destination_region: {destination_name: region_name}
    """
    _ensure_spatial_extension()
    tmp_path = _write_temp_file(file_bytes)

    try:
        df = duckdb.sql(f"""
            SELECT
                upper(trim(Transporter))   AS Transporter,
                trim(Destination)          AS Destination,
                trim(Region)               AS Region,
                "Car"                      AS Cost
            FROM st_read('{tmp_path}')
        """).df()

        # Normalise casing: destinations title-cased, transporters UPPER, regions title-cased
        df["Transporter"] = df["Transporter"].str.upper().str.strip()
        df["Destination"] = df["Destination"].str.strip().str.title()
        df["Region"] = df["Region"].str.strip().str.title()

        transporters_set = sorted(df["Transporter"].unique())
        destinations_set = sorted(df["Destination"].unique())

        transporters = [Category(value=t) for t in transporters_set]
        destinations = [Category(value=d) for d in destinations_set]

        # Build region_map: {region: {"transporter": set, "destination": set}}
        region_map: dict = {}
        for _, row in df.iterrows():
            reg = row["Region"]
            tpt = row["Transporter"]
            dest = row["Destination"]
            if reg not in region_map:
                region_map[reg] = {"transporter": set(), "destination": set()}
            region_map[reg]["transporter"].add(tpt)
            region_map[reg]["destination"].add(dest)

        # Build destination_region: {destination: region}
        destination_region: dict = {}
        for _, row in df.iterrows():
            destination_region[row["Destination"]] = row["Region"]

        # Build cost_matrix: {transporter: {destination: cost}}
        cost_matrix: dict = {
            tpt: {dest: INFINITY for dest in destinations_set}
            for tpt in transporters_set
        }
        for _, row in df.iterrows():
            tpt = row["Transporter"]
            dest = row["Destination"]
            cost = row["Cost"]
            if tpt in cost_matrix and dest in cost_matrix[tpt]:
                cost_matrix[tpt][dest] = float(cost)

        logger.info(
            "Cost file loaded: %d transporters, %d destinations",
            len(transporters), len(destinations),
        )
        return transporters, destinations, region_map, cost_matrix, destination_region

    finally:
        os.unlink(tmp_path)


def load_demand_file(
    file_bytes: bytes,
    destinations: list[Category],
) -> dict:
    """Load demand file.

    Expected columns: Destination, Demand (one row per destination)

    Args:
        file_bytes: Raw bytes of the Demand Excel file.
        destinations: List of Category objects to match against.

    Returns:
        demand dict: {destination_name: quantity}
    """
    _ensure_spatial_extension()
    tmp_path = _write_temp_file(file_bytes)

    try:
        df = duckdb.sql(f"""
            SELECT trim(Destination) AS Destination, Demand
            FROM st_read('{tmp_path}')
        """).df()

        df["Destination"] = df["Destination"].str.strip().str.title()

        demand: dict = {}
        dest_lookup = {cat.value.title(): cat for cat in destinations}

        for _, row in df.iterrows():
            dest_name = row["Destination"]
            qty = int(row["Demand"])
            if dest_name in dest_lookup:
                demand[dest_name] = qty
                dest_lookup[dest_name].is_checked = True

        logger.info("Demand file loaded: %d destinations", len(demand))
        return demand

    finally:
        os.unlink(tmp_path)


def load_supply_file(
    file_bytes: bytes,
    transporters: list[Category],
) -> tuple[dict, dict, dict]:
    """Load supply file.

    Expected columns: Transporter, North, South, East, West, Central

    Args:
        file_bytes: Raw bytes of the Supply Excel file.
        transporters: List of Category objects to match against.

    Returns:
        (supply_total, min_load, regional_supply)
        supply_total:    {transporter: total_qty}
        min_load:        {transporter: 0}  (editable in UI)
        regional_supply: {transporter: {"North": n, "South": s, ...}}
    """
    _ensure_spatial_extension()
    tmp_path = _write_temp_file(file_bytes)

    try:
        df = duckdb.sql(f"""
            SELECT
                upper(trim(Transporter)) AS Transporter,
                coalesce("North",   0)  AS North,
                coalesce("South",   0)  AS South,
                coalesce("East",    0)  AS East,
                coalesce("West",    0)  AS West,
                coalesce("Central", 0)  AS Central
            FROM st_read('{tmp_path}')
        """).df()

        supply_total: dict = {}
        min_load: dict = {}
        regional_supply: dict = {}

        tpt_lookup = {cat.value.upper(): cat for cat in transporters}

        for _, row in df.iterrows():
            tpt_name = row["Transporter"]
            if tpt_name not in tpt_lookup:
                continue
            cat = tpt_lookup[tpt_name]
            cat.is_checked = True

            reg_qty = {col: int(row[col]) for col in REGION_COLS}
            total = sum(reg_qty.values())

            supply_total[cat.value] = total
            min_load[cat.value] = 0
            regional_supply[cat.value] = reg_qty

        logger.info("Supply file loaded: %d transporters", len(supply_total))
        return supply_total, min_load, regional_supply

    finally:
        os.unlink(tmp_path)
