import io
import logging
from datetime import datetime

import xlsxwriter

from models.enums import AllocationState

logger = logging.getLogger(__name__)


def generate_export(
    supply: dict,
    demand: dict,
    allocation: dict,
    cost_matrix: dict,
    min_load: dict,
    super_optimal_allocation: dict,
    super_optimal_cost: float,
    optimal_cost: float,
    carrier_number: int,
    allocation_history: list,
) -> bytes:
    """Generate a multi-sheet Excel export and return as bytes.

    Returns:
        bytes: The Excel workbook content, suitable for st.download_button.
    """
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output, {"in_memory": True})

    heading_fmt = workbook.add_format({"bold": True, "bg_color": "#C0C0C0"})
    currency_fmt = workbook.add_format({"num_format": "\u20b9#,##0.00"})
    savings_fmt = workbook.add_format({"num_format": "\u20b9#,##0.00", "bg_color": "#C6EFCE"})
    allocation_fmt = workbook.add_format({"bg_color": "#C6EFCE"})

    transporter = sorted(list(supply.keys()))
    destination = sorted(list(demand.keys()))

    # --- Sheet 1: Supply and Demand ---
    ws_sd = workbook.add_worksheet("Supply and Demand")
    ws_sd.write("A1", "Destination", heading_fmt)
    ws_sd.write("B1", "Demand", heading_fmt)
    ws_sd.write("D1", "Transporter", heading_fmt)
    ws_sd.write("E1", "Supply", heading_fmt)
    ws_sd.write("F1", "Minimum", heading_fmt)

    for i, city in enumerate(destination, start=1):
        ws_sd.write(i, 0, city)
        ws_sd.write(i, 1, demand[city])

    for i, tpt in enumerate(transporter, start=1):
        ws_sd.write(i, 3, tpt)
        ws_sd.write(i, 4, supply[tpt])
        ws_sd.write(i, 5, min_load.get(tpt, 0))

    ws_sd.autofit()

    # --- Sheet 2: Allocation Entry (list format) ---
    ws_entry = workbook.add_worksheet("Allocation Entry")
    for j, heading in enumerate(["Destination", "Transporter", "Load"]):
        ws_entry.write(0, j, heading, heading_fmt)

    i = 1
    for city in demand.keys():
        for tpt in supply.keys():
            if allocation[city][tpt]["value"] != 0:
                ws_entry.write(i, 0, city)
                ws_entry.write(i, 1, tpt)
                ws_entry.write(i, 2, allocation[city][tpt]["value"])
                i += 1
    ws_entry.autofit()

    # --- Sheet 3: Allocation Matrix ---
    ws_matrix = workbook.add_worksheet("Allocation Matrix")
    max_tpt_len = max((len(t) for t in supply.keys()), default=10)
    max_city_len = max((len(c) for c in demand.keys()), default=10)

    ws_matrix.write(0, 0, "", heading_fmt)
    ws_matrix.set_column(0, 0, max_city_len + 2)
    ws_matrix.set_column(1, len(supply), max_tpt_len + 2)

    for j, tpt in enumerate(supply.keys(), start=1):
        ws_matrix.write(0, j, tpt, heading_fmt)

    for i, city in enumerate(demand.keys(), start=1):
        ws_matrix.write(i, 0, city, heading_fmt)
        for j, tpt in enumerate(supply.keys(), start=1):
            val = allocation[city][tpt]["value"]
            fmt = allocation_fmt if val != 0 else None
            ws_matrix.write(i, j, val, fmt)
        ws_matrix.write(i, len(supply) + 1, demand[city])

    supply_row = len(demand) + 1
    for j, tpt in enumerate(supply.keys(), start=1):
        ws_matrix.write(supply_row, j, supply[tpt])

    # Cost matrix section (below allocation)
    cost_start = supply_row + 3
    ws_matrix.write(cost_start, 0, "", heading_fmt)
    for j, tpt in enumerate(supply.keys(), start=1):
        ws_matrix.write(cost_start, j, tpt, heading_fmt)

    for i, city in enumerate(demand.keys(), start=1):
        ws_matrix.write(cost_start + i, 0, city, heading_fmt)
        for j, tpt in enumerate(supply.keys(), start=1):
            val = allocation[city][tpt]["value"]
            cost_val = cost_matrix[tpt][city]
            fmt = allocation_fmt if val != 0 else None
            ws_matrix.write(cost_start + i, j, cost_val, fmt)

    # Super Optimal Allocation section
    so_start = cost_start + len(demand) + 3
    ws_matrix.merge_range(
        so_start - 1, 0, so_start - 1, len(supply), "Super Optimal Allocation", heading_fmt
    )
    ws_matrix.write(so_start, 0, "", heading_fmt)
    for j, tpt in enumerate(supply.keys(), start=1):
        ws_matrix.write(so_start, j, tpt, heading_fmt)

    for i, city in enumerate(demand.keys(), start=1):
        ws_matrix.write(so_start + i, 0, city, heading_fmt)
        for j, tpt in enumerate(supply.keys(), start=1):
            val = super_optimal_allocation.get(city, {}).get(tpt, {})
            if isinstance(val, dict):
                val = val.get("value", 0)
            fmt = allocation_fmt if val != 0 else None
            ws_matrix.write(so_start + i, j, val, fmt)

    ws_matrix.autofit()

    # --- Sheet 4: Rejected and Locked Allocation ---
    ws_rej = workbook.add_worksheet("Rejected and Locked Allocation")
    for j, heading in enumerate(["S.No", "Transporter", "Destination", "Status"]):
        ws_rej.write(0, j, heading, heading_fmt)

    i = 1
    for tpt in supply.keys():
        for city in demand.keys():
            state = allocation[city][tpt]["state"]
            if state in (AllocationState.BLOCKED, AllocationState.LOCKED):
                ws_rej.write(i, 0, i)
                ws_rej.write(i, 1, tpt)
                ws_rej.write(i, 2, city)
                ws_rej.write(i, 3, "Rejected" if state == AllocationState.BLOCKED else "Locked")
                i += 1

    # Cost summary columns
    first_cost = allocation_history[0][1] * carrier_number if allocation_history else 0
    actual_cost = optimal_cost * carrier_number
    overrun = round((actual_cost - first_cost) / first_cost, 5) if first_cost else 0

    ws_rej.write(0, 5, "Super Optimal Cost", heading_fmt)
    ws_rej.write(0, 6, super_optimal_cost * carrier_number, currency_fmt)
    ws_rej.write(1, 5, "Optimal Cost", heading_fmt)
    ws_rej.write(1, 6, first_cost, currency_fmt)
    ws_rej.write(2, 5, "Actual Allocation Cost", heading_fmt)
    ws_rej.write(2, 6, actual_cost, currency_fmt)
    ws_rej.write(3, 5, "Difference vs Optimal", heading_fmt)
    ws_rej.write(3, 6, actual_cost - first_cost, currency_fmt)
    ws_rej.write(4, 5, "Cost Overrun Rate", heading_fmt)
    ws_rej.write(4, 6, overrun)
    ws_rej.write(5, 5, "Total Cost Savings vs Super Optimal", heading_fmt)
    ws_rej.write(5, 6, super_optimal_cost * carrier_number - actual_cost, savings_fmt)
    ws_rej.autofit()

    workbook.close()
    output.seek(0)
    logger.info("Export generated successfully.")
    return output.getvalue()


def get_export_filename() -> str:
    return f"Allocation_File_{datetime.now().strftime('%Y%m%d%H%M%S')}.xlsx"
