"""
Generate demo input files for the Transportation Cost Optimizer.

Data is designed so that ONE set of 3 files covers ALL demo scenarios:
  1. Optimizer vs Intuition  — manual greedy costs 940, optimizer finds 795 (15% savings)
  2. Basic allocation workflow
  3. Super Optimal vs Optimal — min load causes visible cost increase
  4. Min Load constraints    — DELTA forced to ship, cost rises 3.8%
  5. Manual cell editing
  6. Lock feature            — locking ALPHA->Chennai=25 costs +13.2%
  7. Block feature           — blocking ALPHA->Coimbatore costs +25.2%
  8. Multi-step reallocation
  9. Bar chart visualization

Run:
    python demo_files/create_demo_files.py

Files produced (in demo_files/):
    Cost.xlsx       — 4 transporters x 3 destinations = 12 routes
    Demand.xlsx     — 3 destinations
    Supply.xlsx     — 4 transporters with regional supply
    Comparison.xlsx — Multi-sheet scenario comparison with formulas
"""

import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

# ═══════════════════════════════════════════════════════════════════════════════
# DATA DESIGN NOTES
# ═══════════════════════════════════════════════════════════════════════════════
#
# 4 Transporters:  ALPHA, BETA, GAMMA, DELTA
# 3 Destinations:  Chennai (South), Coimbatore (South), Hyderabad (Central)
#
# ALPHA is cheapest for BOTH Chennai(13) AND Coimbatore(7) — same region (South).
# A human naturally maxes out ALPHA on Chennai first (cheapest there: 13),
# leaving only 5 units of ALPHA's South capacity for Coimbatore.
# But ALPHA saves 8/unit on Coimbatore (7 vs next-cheapest 15) while only
# saving 1/unit on Chennai (13 vs 14). The optimizer "sacrifices" Chennai
# to more expensive transporters to free ALPHA for Coimbatore.
#
# Verified solver results:
#   Super Optimal (no min_load)       = 795   (ALPHA→10 Chennai + 25 Coimbatore)
#   Manual greedy                     = 940   (ALPHA→30 Chennai, then scramble)
#   Savings                           = 15.4%
#
#   Min load DELTA=10                 = 825   (+3.8% vs Super Optimal)
#   Block ALPHA→Coimbatore            = 995   (+25.2%)
#   Lock ALPHA→Chennai=25             = 900   (+13.2%)
# ═══════════════════════════════════════════════════════════════════════════════

TRANSPORTERS = ["ALPHA", "BETA", "GAMMA", "DELTA"]

DESTINATIONS = {
    "Chennai":    "South",
    "Coimbatore": "South",
    "Hyderabad":  "Central",
}

DEST_LIST = list(DESTINATIONS.keys())  # ordered

#                       Chennai  Coimbatore  Hyderabad
COST_MATRIX = {
    "ALPHA": [13,  7, 20],
    "BETA":  [14, 15,  8],
    "GAMMA": [16, 18, 18],
    "DELTA": [18, 20, 12],
}

# Regional supply
#                   North  South  East  West  Central
REGIONAL_SUPPLY = {
    "ALPHA": ( 0, 35, 0, 0,  0),  # Total = 35 (South only)
    "BETA":  ( 0, 15, 0, 0, 25),  # Total = 40 (mostly Central)
    "GAMMA": ( 0, 20, 0, 0, 10),  # Total = 30 (split S/C)
    "DELTA": ( 0, 10, 0, 0, 15),  # Total = 25 (mostly Central)
}
# Total supply   = 130
# South supply   = 35+15+20+10 = 80  (South demand   = 30+25 = 55) ✓
# Central supply = 0+25+10+15  = 50  (Central demand  = 25)          ✓

DEMAND = {
    "Chennai":    30,
    "Coimbatore": 25,
    "Hyderabad":  25,
}
# Total demand = 80, surplus = 50

# ── Pre-verified allocation results ──────────────────────────────────────────
# Used to build the Comparison Excel with exact numbers

OPTIMAL_ALLOC = {
    "ALPHA": {"Chennai": 10, "Coimbatore": 25, "Hyderabad": 0},
    "BETA":  {"Chennai": 15, "Coimbatore": 0,  "Hyderabad": 25},
    "GAMMA": {"Chennai": 5,  "Coimbatore": 0,  "Hyderabad": 0},
    "DELTA": {"Chennai": 0,  "Coimbatore": 0,  "Hyderabad": 0},
}

GREEDY_ALLOC = {
    "ALPHA": {"Chennai": 30, "Coimbatore": 5, "Hyderabad": 0},
    "BETA":  {"Chennai": 0,  "Coimbatore": 15, "Hyderabad": 25},
    "GAMMA": {"Chennai": 0,  "Coimbatore": 5,  "Hyderabad": 0},
    "DELTA": {"Chennai": 0,  "Coimbatore": 0,  "Hyderabad": 0},
}

MINLOAD_ALLOC = {
    "ALPHA": {"Chennai": 10, "Coimbatore": 25, "Hyderabad": 0},
    "BETA":  {"Chennai": 10, "Coimbatore": 0,  "Hyderabad": 25},
    "GAMMA": {"Chennai": 0,  "Coimbatore": 0,  "Hyderabad": 0},
    "DELTA": {"Chennai": 10, "Coimbatore": 0,  "Hyderabad": 0},
}

BLOCK_ALLOC = {
    "ALPHA": {"Chennai": 30, "Coimbatore": 0,  "Hyderabad": 0},
    "BETA":  {"Chennai": 0,  "Coimbatore": 15, "Hyderabad": 25},
    "GAMMA": {"Chennai": 0,  "Coimbatore": 10, "Hyderabad": 0},
    "DELTA": {"Chennai": 0,  "Coimbatore": 0,  "Hyderabad": 0},
}

LOCK_ALLOC = {
    "ALPHA": {"Chennai": 25, "Coimbatore": 10, "Hyderabad": 0},
    "BETA":  {"Chennai": 0,  "Coimbatore": 15, "Hyderabad": 25},
    "GAMMA": {"Chennai": 5,  "Coimbatore": 0,  "Hyderabad": 0},
    "DELTA": {"Chennai": 0,  "Coimbatore": 0,  "Hyderabad": 0},
}


# ── Styles ───────────────────────────────────────────────────────────────────

HEADER_FONT  = Font(bold=True, color="FFFFFF", size=11)
HEADER_ALIGN = Alignment(horizontal="center", vertical="center")
DATA_ALIGN   = Alignment(horizontal="center", vertical="center")
BOLD_FONT    = Font(bold=True, size=11)
TITLE_FONT   = Font(bold=True, size=14, color="1F4E79")
SUBTITLE_FONT = Font(bold=True, size=11, color="375623")
NUM_FMT_COMMA = '#,##0'
NUM_FMT_PCT   = '0.0%'

THIN_BORDER = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin'),
)

# Colour fills
FILL_HEADER_BLUE   = PatternFill("solid", fgColor="1F4E79")
FILL_HEADER_GREEN  = PatternFill("solid", fgColor="375623")
FILL_HEADER_RED    = PatternFill("solid", fgColor="7B2C2C")
FILL_HEADER_ORANGE = PatternFill("solid", fgColor="C65911")
FILL_HEADER_PURPLE = PatternFill("solid", fgColor="7030A0")
FILL_LIGHT_GREEN   = PatternFill("solid", fgColor="E2EFDA")
FILL_LIGHT_RED     = PatternFill("solid", fgColor="FCE4EC")
FILL_LIGHT_YELLOW  = PatternFill("solid", fgColor="FFF9C4")
FILL_LIGHT_BLUE    = PatternFill("solid", fgColor="D6EAF8")
FILL_LIGHT_ORANGE  = PatternFill("solid", fgColor="FDEBD0")
FILL_LIGHT_PURPLE  = PatternFill("solid", fgColor="E8DAEF")
FILL_WHITE         = PatternFill("solid", fgColor="FFFFFF")
FILL_SAVINGS       = PatternFill("solid", fgColor="C6EFCE")
FILL_EXTRA_COST    = PatternFill("solid", fgColor="FFC7CE")


def _style_header(ws, headers, fill):
    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = HEADER_FONT
        cell.fill = fill
        cell.alignment = HEADER_ALIGN
        cell.border = THIN_BORDER


def _auto_width(ws, min_width=10):
    for col_cells in ws.columns:
        max_len = max((len(str(c.value or "")) for c in col_cells), default=10)
        ws.column_dimensions[get_column_letter(col_cells[0].column)].width = max(max_len + 3, min_width)


def _write_cell(ws, row, col, value, font=None, fill=None, align=DATA_ALIGN,
                border=THIN_BORDER, num_fmt=None):
    cell = ws.cell(row=row, column=col, value=value)
    if font:   cell.font = font
    if fill:   cell.fill = fill
    if align:  cell.alignment = align
    if border: cell.border = border
    if num_fmt: cell.number_format = num_fmt
    return cell


# ── Cost File ────────────────────────────────────────────────────────────────

def create_cost_file():
    wb = Workbook()
    ws = wb.active
    ws.title = "Cost"
    _style_header(ws, ["Transporter", "Destination", "Region", "Car"], FILL_HEADER_BLUE)

    row = 2
    for tpt in TRANSPORTERS:
        for i, dest in enumerate(DEST_LIST):
            cost = COST_MATRIX[tpt][i]
            _write_cell(ws, row, 1, tpt)
            _write_cell(ws, row, 2, dest)
            _write_cell(ws, row, 3, DESTINATIONS[dest])
            _write_cell(ws, row, 4, cost)
            row += 1

    _auto_width(ws)
    path = os.path.join(OUTPUT_DIR, "Cost.xlsx")
    wb.save(path)
    print(f"  Cost.xlsx     - {row - 2} routes")


# ── Demand File ──────────────────────────────────────────────────────────────

def create_demand_file():
    wb = Workbook()
    ws = wb.active
    ws.title = "Demand"
    _style_header(ws, ["Destination", "Demand"], FILL_HEADER_GREEN)

    for row, (dest, qty) in enumerate(DEMAND.items(), start=2):
        _write_cell(ws, row, 1, dest)
        _write_cell(ws, row, 2, qty)

    _auto_width(ws)
    path = os.path.join(OUTPUT_DIR, "Demand.xlsx")
    wb.save(path)
    print(f"  Demand.xlsx   - {len(DEMAND)} destinations, total = {sum(DEMAND.values())}")


# ── Supply File ──────────────────────────────────────────────────────────────

def create_supply_file():
    wb = Workbook()
    ws = wb.active
    ws.title = "Supply"
    headers = ["Transporter", "North", "South", "East", "West", "Central"]
    _style_header(ws, headers, FILL_HEADER_RED)

    for row, tpt in enumerate(TRANSPORTERS, start=2):
        n, s, e, w, c = REGIONAL_SUPPLY[tpt]
        _write_cell(ws, row, 1, tpt)
        _write_cell(ws, row, 2, n)
        _write_cell(ws, row, 3, s)
        _write_cell(ws, row, 4, e)
        _write_cell(ws, row, 5, w)
        _write_cell(ws, row, 6, c)

    _auto_width(ws)
    path = os.path.join(OUTPUT_DIR, "Supply.xlsx")
    wb.save(path)
    total = sum(sum(v) for v in REGIONAL_SUPPLY.values())
    print(f"  Supply.xlsx   - {len(TRANSPORTERS)} transporters, total = {total}")


# ── Comparison Excel (multi-sheet with formulas) ─────────────────────────────

def _build_alloc_block(ws, start_row, title, title_fill, data_fill, header_fill,
                       alloc_dict, cost_ref_row_start):
    """
    Write an allocation matrix block (title + header + 4 transporter rows + total row)
    with FORMULA-based cost calculation.

    Returns the row after the block (for chaining).

    Layout (example for start_row=3):
      Row 3: title merged across cols 1-8
      Row 4: header — Transporter | Chennai | Coimbatore | Hyderabad | Total Qty | Cost/Unit Ref | Route Cost | Total Cost
      Row 5-8: data rows (one per transporter)
      Row 9: TOTAL row with SUM formulas
      Row 10: blank spacer
    """
    title_row = start_row
    header_row = start_row + 1
    data_start = start_row + 2
    ncols = 8  # A..H

    # Title
    ws.merge_cells(start_row=title_row, start_column=1,
                   end_row=title_row, end_column=ncols)
    _write_cell(ws, title_row, 1, title,
                font=Font(bold=True, size=12, color="FFFFFF"), fill=title_fill,
                align=Alignment(horizontal="center", vertical="center"))

    # Headers
    headers = ["Transporter", "Chennai", "Coimbatore", "Hyderabad",
               "Total Qty", "Cost Lookup", "Route Cost", "Total Cost"]
    for c, h in enumerate(headers, 1):
        _write_cell(ws, header_row, c, h, font=HEADER_FONT, fill=header_fill)

    # Data rows
    for i, tpt in enumerate(TRANSPORTERS):
        r = data_start + i
        _write_cell(ws, r, 1, tpt, font=BOLD_FONT, fill=data_fill)

        for j, dest in enumerate(DEST_LIST):
            qty = alloc_dict[tpt][dest]
            _write_cell(ws, r, 2 + j, qty, fill=data_fill)

        # Col E: Total Qty = SUM(B:D)
        _write_cell(ws, r, 5, None, fill=data_fill, num_fmt=NUM_FMT_COMMA)
        ws.cell(row=r, column=5).value = f"=SUM(B{r}:D{r})"

        # Col F: Cost lookup text (for reference only)
        costs = [COST_MATRIX[tpt][k] for k in range(len(DEST_LIST))]
        cost_str = " / ".join(str(c) for c in costs)
        _write_cell(ws, r, 6, cost_str, fill=data_fill,
                    align=Alignment(horizontal="center"))

        # Col G: Route Cost = B*cost_chen + C*cost_coi + D*cost_hyd
        c_chen, c_coi, c_hyd = COST_MATRIX[tpt]
        formula = f"=B{r}*{c_chen}+C{r}*{c_coi}+D{r}*{c_hyd}"
        _write_cell(ws, r, 7, None, fill=data_fill, num_fmt=NUM_FMT_COMMA)
        ws.cell(row=r, column=7).value = formula

        # Col H: same as G (individual transporter total)
        _write_cell(ws, r, 8, None, fill=data_fill, num_fmt=NUM_FMT_COMMA)
        ws.cell(row=r, column=8).value = f"=G{r}"

    # Total row
    total_row = data_start + len(TRANSPORTERS)
    _write_cell(ws, total_row, 1, "TOTAL", font=BOLD_FONT,
                fill=PatternFill("solid", fgColor="D9E1F2"))

    for c in range(2, 6):  # B to E
        _write_cell(ws, total_row, c, None,
                    font=BOLD_FONT, fill=PatternFill("solid", fgColor="D9E1F2"),
                    num_fmt=NUM_FMT_COMMA)
        col_letter = get_column_letter(c)
        ws.cell(row=total_row, column=c).value = \
            f"=SUM({col_letter}{data_start}:{col_letter}{data_start + len(TRANSPORTERS) - 1})"

    _write_cell(ws, total_row, 6, "", fill=PatternFill("solid", fgColor="D9E1F2"))

    for c in [7, 8]:
        _write_cell(ws, total_row, c, None,
                    font=Font(bold=True, size=12), fill=PatternFill("solid", fgColor="D9E1F2"),
                    num_fmt=NUM_FMT_COMMA)
        col_letter = get_column_letter(c)
        ws.cell(row=total_row, column=c).value = \
            f"=SUM({col_letter}{data_start}:{col_letter}{data_start + len(TRANSPORTERS) - 1})"

    return total_row + 2  # leave a blank row


def create_comparison_file():
    wb = Workbook()

    # ── Sheet 1: Greedy vs Optimal ────────────────────────────────────────────
    ws1 = wb.active
    ws1.title = "Greedy vs Optimal"
    ws1.sheet_properties.tabColor = "1F4E79"

    # Title
    _write_cell(ws1, 1, 1, "SCENARIO 1: Manual (Greedy) vs Optimizer",
                font=TITLE_FONT, fill=FILL_WHITE, border=None)
    ws1.merge_cells("A1:H1")

    # Cost matrix reference
    _write_cell(ws1, 2, 1, "Cost per unit:  ALPHA(13/7/20)  BETA(14/15/8)  GAMMA(16/18/18)  DELTA(18/20/12)",
                font=Font(italic=True, size=10, color="666666"), fill=FILL_WHITE, border=None)
    ws1.merge_cells("A2:H2")

    # Greedy block
    next_row = _build_alloc_block(
        ws1, start_row=4,
        title="MANUAL GREEDY ALLOCATION (Human Approach)",
        title_fill=FILL_HEADER_RED,
        data_fill=FILL_LIGHT_RED,
        header_fill=PatternFill("solid", fgColor="C0392B"),
        alloc_dict=GREEDY_ALLOC,
        cost_ref_row_start=4,
    )

    # Optimal block
    next_row2 = _build_alloc_block(
        ws1, start_row=next_row,
        title="OPTIMIZER ALLOCATION (Cost Optimizer Tool)",
        title_fill=FILL_HEADER_GREEN,
        data_fill=FILL_LIGHT_GREEN,
        header_fill=PatternFill("solid", fgColor="27AE60"),
        alloc_dict=OPTIMAL_ALLOC,
        cost_ref_row_start=next_row,
    )

    # Summary comparison
    sr = next_row2
    _write_cell(ws1, sr, 1, "COMPARISON SUMMARY",
                font=Font(bold=True, size=12, color="FFFFFF"),
                fill=FILL_HEADER_BLUE)
    ws1.merge_cells(start_row=sr, start_column=1, end_row=sr, end_column=4)

    greedy_total_cell = f"H{next_row - 2}"    # total row of greedy block
    optimal_total_cell = f"H{next_row2 - 2}"  # total row of optimal block

    labels = ["Manual Greedy Cost", "Optimizer Cost", "Savings (Absolute)", "Savings (%)"]
    formulas = [
        f"={greedy_total_cell}",
        f"={optimal_total_cell}",
        f"={greedy_total_cell}-{optimal_total_cell}",
        f"=({greedy_total_cell}-{optimal_total_cell})/{greedy_total_cell}",
    ]
    fills = [FILL_LIGHT_RED, FILL_LIGHT_GREEN, FILL_SAVINGS, FILL_SAVINGS]
    fmts = [NUM_FMT_COMMA, NUM_FMT_COMMA, NUM_FMT_COMMA, NUM_FMT_PCT]

    for i, (label, formula, fill, fmt) in enumerate(zip(labels, formulas, fills, fmts)):
        r = sr + 1 + i
        _write_cell(ws1, r, 1, label, font=BOLD_FONT, fill=fill)
        ws1.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        _write_cell(ws1, r, 3, None, font=Font(bold=True, size=13), fill=fill, num_fmt=fmt)
        ws1.cell(row=r, column=3).value = formula

    # Insight box
    insight_row = sr + 6
    _write_cell(ws1, insight_row, 1,
                "WHY? ALPHA saves only 1/unit on Chennai (13 vs 14) but saves 8/unit on Coimbatore (7 vs 15).",
                font=Font(italic=True, size=10, color="1F4E79"), border=None)
    ws1.merge_cells(start_row=insight_row, start_column=1, end_row=insight_row, end_column=8)
    _write_cell(ws1, insight_row + 1, 1,
                "The optimizer 'sacrifices' Chennai to free ALPHA for Coimbatore — saving 15% overall.",
                font=Font(italic=True, size=10, color="1F4E79"), border=None)
    ws1.merge_cells(start_row=insight_row+1, start_column=1, end_row=insight_row+1, end_column=8)

    _auto_width(ws1, min_width=12)
    ws1.column_dimensions["A"].width = 16

    # ── Sheet 2: Min Load Impact ──────────────────────────────────────────────
    ws2 = wb.create_sheet("Min Load Impact")
    ws2.sheet_properties.tabColor = "C65911"

    _write_cell(ws2, 1, 1, "SCENARIO 4: Impact of Minimum Load Constraint (DELTA Min Load = 10)",
                font=TITLE_FONT, fill=FILL_WHITE, border=None)
    ws2.merge_cells("A1:H1")
    _write_cell(ws2, 2, 1, "DELTA must ship at least 10 units. Without this rule, DELTA ships 0 (too expensive).",
                font=Font(italic=True, size=10, color="666666"), fill=FILL_WHITE, border=None)
    ws2.merge_cells("A2:H2")

    next_row = _build_alloc_block(
        ws2, 4, "WITHOUT MIN LOAD (Super Optimal = Free solver)",
        FILL_HEADER_GREEN, FILL_LIGHT_GREEN,
        PatternFill("solid", fgColor="27AE60"),
        OPTIMAL_ALLOC, 4,
    )
    next_row2 = _build_alloc_block(
        ws2, next_row, "WITH MIN LOAD: DELTA >= 10",
        FILL_HEADER_ORANGE, FILL_LIGHT_ORANGE,
        PatternFill("solid", fgColor="E67E22"),
        MINLOAD_ALLOC, next_row,
    )

    sr = next_row2
    _write_cell(ws2, sr, 1, "CONSTRAINT COST",
                font=Font(bold=True, size=12, color="FFFFFF"), fill=FILL_HEADER_ORANGE)
    ws2.merge_cells(start_row=sr, start_column=1, end_row=sr, end_column=4)

    opt_cell = f"H{next_row - 2}"
    ml_cell = f"H{next_row2 - 2}"

    for i, (label, formula, fill, fmt) in enumerate([
        ("Super Optimal Cost", f"={opt_cell}", FILL_LIGHT_GREEN, NUM_FMT_COMMA),
        ("With Min Load Cost", f"={ml_cell}", FILL_LIGHT_ORANGE, NUM_FMT_COMMA),
        ("Extra Cost", f"={ml_cell}-{opt_cell}", FILL_EXTRA_COST, NUM_FMT_COMMA),
        ("% Increase", f"=({ml_cell}-{opt_cell})/{opt_cell}", FILL_EXTRA_COST, NUM_FMT_PCT),
    ]):
        r = sr + 1 + i
        _write_cell(ws2, r, 1, label, font=BOLD_FONT, fill=fill)
        ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        _write_cell(ws2, r, 3, None, font=Font(bold=True, size=13), fill=fill, num_fmt=fmt)
        ws2.cell(row=r, column=3).value = formula

    _write_cell(ws2, sr + 6, 1,
                "The minimum load rule forces DELTA to ship 10 units to Chennai at 18/unit — replacing cheaper BETA at 14/unit.",
                font=Font(italic=True, size=10, color="C65911"), border=None)
    ws2.merge_cells(start_row=sr+6, start_column=1, end_row=sr+6, end_column=8)

    _auto_width(ws2, min_width=12)
    ws2.column_dimensions["A"].width = 16

    # ── Sheet 3: Block Route Impact ───────────────────────────────────────────
    ws3 = wb.create_sheet("Block Route Impact")
    ws3.sheet_properties.tabColor = "C0392B"

    _write_cell(ws3, 1, 1, "SCENARIO 7: Impact of Blocking ALPHA to Coimbatore",
                font=TITLE_FONT, fill=FILL_WHITE, border=None)
    ws3.merge_cells("A1:H1")
    _write_cell(ws3, 2, 1,
                "ALPHA cannot ship to Coimbatore (warehouse closure / contract issue). Route blocked.",
                font=Font(italic=True, size=10, color="666666"), fill=FILL_WHITE, border=None)
    ws3.merge_cells("A2:H2")

    next_row = _build_alloc_block(
        ws3, 4, "OPTIMAL (All routes available)",
        FILL_HEADER_GREEN, FILL_LIGHT_GREEN,
        PatternFill("solid", fgColor="27AE60"),
        OPTIMAL_ALLOC, 4,
    )
    next_row2 = _build_alloc_block(
        ws3, next_row, "BLOCKED: ALPHA to Coimbatore = 0",
        FILL_HEADER_RED, FILL_LIGHT_RED,
        PatternFill("solid", fgColor="C0392B"),
        BLOCK_ALLOC, next_row,
    )

    sr = next_row2
    _write_cell(ws3, sr, 1, "DISRUPTION COST",
                font=Font(bold=True, size=12, color="FFFFFF"), fill=FILL_HEADER_RED)
    ws3.merge_cells(start_row=sr, start_column=1, end_row=sr, end_column=4)

    opt_cell = f"H{next_row - 2}"
    blk_cell = f"H{next_row2 - 2}"

    for i, (label, formula, fill, fmt) in enumerate([
        ("Optimal Cost", f"={opt_cell}", FILL_LIGHT_GREEN, NUM_FMT_COMMA),
        ("Blocked Route Cost", f"={blk_cell}", FILL_LIGHT_RED, NUM_FMT_COMMA),
        ("Extra Cost", f"={blk_cell}-{opt_cell}", FILL_EXTRA_COST, NUM_FMT_COMMA),
        ("% Increase", f"=({blk_cell}-{opt_cell})/{opt_cell}", FILL_EXTRA_COST, NUM_FMT_PCT),
    ]):
        r = sr + 1 + i
        _write_cell(ws3, r, 1, label, font=BOLD_FONT, fill=fill)
        ws3.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        _write_cell(ws3, r, 3, None, font=Font(bold=True, size=13), fill=fill, num_fmt=fmt)
        ws3.cell(row=r, column=3).value = formula

    _write_cell(ws3, sr + 6, 1,
                "ALPHA was the cheapest route to Coimbatore (7/unit). Without it, Coimbatore uses BETA (15) & GAMMA (18) — a +25% cost jump.",
                font=Font(italic=True, size=10, color="C0392B"), border=None)
    ws3.merge_cells(start_row=sr+6, start_column=1, end_row=sr+6, end_column=8)
    _write_cell(ws3, sr + 7, 1,
                "If this is a contract dispute, you now know the negotiation ceiling: resolving it saves 200 per cycle.",
                font=Font(italic=True, size=10, color="C0392B"), border=None)
    ws3.merge_cells(start_row=sr+7, start_column=1, end_row=sr+7, end_column=8)

    _auto_width(ws3, min_width=12)
    ws3.column_dimensions["A"].width = 16

    # ── Sheet 4: Lock Route Impact ────────────────────────────────────────────
    ws4 = wb.create_sheet("Lock Route Impact")
    ws4.sheet_properties.tabColor = "7030A0"

    _write_cell(ws4, 1, 1, "SCENARIO 6: Impact of Locking ALPHA to Chennai = 25",
                font=TITLE_FONT, fill=FILL_WHITE, border=None)
    ws4.merge_cells("A1:H1")
    _write_cell(ws4, 2, 1,
                "Management mandates ALPHA must deliver exactly 25 to Chennai (vs optimizer's 10).",
                font=Font(italic=True, size=10, color="666666"), fill=FILL_WHITE, border=None)
    ws4.merge_cells("A2:H2")

    next_row = _build_alloc_block(
        ws4, 4, "OPTIMAL (Solver decides freely)",
        FILL_HEADER_GREEN, FILL_LIGHT_GREEN,
        PatternFill("solid", fgColor="27AE60"),
        OPTIMAL_ALLOC, 4,
    )
    next_row2 = _build_alloc_block(
        ws4, next_row, "LOCKED: ALPHA to Chennai = 25 (fixed)",
        FILL_HEADER_PURPLE, FILL_LIGHT_PURPLE,
        PatternFill("solid", fgColor="8E44AD"),
        LOCK_ALLOC, next_row,
    )

    sr = next_row2
    _write_cell(ws4, sr, 1, "OVERRIDE COST",
                font=Font(bold=True, size=12, color="FFFFFF"), fill=FILL_HEADER_PURPLE)
    ws4.merge_cells(start_row=sr, start_column=1, end_row=sr, end_column=4)

    opt_cell = f"H{next_row - 2}"
    lck_cell = f"H{next_row2 - 2}"

    for i, (label, formula, fill, fmt) in enumerate([
        ("Optimal Cost", f"={opt_cell}", FILL_LIGHT_GREEN, NUM_FMT_COMMA),
        ("Locked Route Cost", f"={lck_cell}", FILL_LIGHT_PURPLE, NUM_FMT_COMMA),
        ("Extra Cost", f"={lck_cell}-{opt_cell}", FILL_EXTRA_COST, NUM_FMT_COMMA),
        ("% Increase", f"=({lck_cell}-{opt_cell})/{opt_cell}", FILL_EXTRA_COST, NUM_FMT_PCT),
    ]):
        r = sr + 1 + i
        _write_cell(ws4, r, 1, label, font=BOLD_FONT, fill=fill)
        ws4.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        _write_cell(ws4, r, 3, None, font=Font(bold=True, size=13), fill=fill, num_fmt=fmt)
        ws4.cell(row=r, column=3).value = formula

    _write_cell(ws4, sr + 6, 1,
                "Forcing 25 from ALPHA to Chennai leaves only 10 for Coimbatore (vs optimal 25). Coimbatore gets 15 from BETA at 15/unit instead of 7.",
                font=Font(italic=True, size=10, color="7030A0"), border=None)
    ws4.merge_cells(start_row=sr+6, start_column=1, end_row=sr+6, end_column=8)
    _write_cell(ws4, sr + 7, 1,
                "Cost of this management decision: +13.2%. Is the mandate worth it?",
                font=Font(italic=True, size=10, color="7030A0"), border=None)
    ws4.merge_cells(start_row=sr+7, start_column=1, end_row=sr+7, end_column=8)

    _auto_width(ws4, min_width=12)
    ws4.column_dimensions["A"].width = 16

    # ── Sheet 5: All Scenarios Summary ────────────────────────────────────────
    ws5 = wb.create_sheet("Summary")
    ws5.sheet_properties.tabColor = "1F4E79"

    _write_cell(ws5, 1, 1, "ALL SCENARIOS — COST COMPARISON",
                font=Font(bold=True, size=14, color="FFFFFF"),
                fill=FILL_HEADER_BLUE, border=None)
    ws5.merge_cells("A1:E1")

    headers = ["Scenario", "Total Cost", "vs Optimal", "Extra Cost", "Key Insight"]
    for c, h in enumerate(headers, 1):
        _write_cell(ws5, 3, c, h, font=HEADER_FONT, fill=FILL_HEADER_BLUE)

    scenarios = [
        ("Manual Greedy (Human)", 940, FILL_LIGHT_RED,
         "Human picks cheapest per destination one by one"),
        ("Super Optimal (No constraints)", 795, FILL_LIGHT_BLUE,
         "Theoretical minimum — full solver freedom"),
        ("Optimal (Baseline)", 795, FILL_LIGHT_GREEN,
         "Best achievable with all constraints (no min load here)"),
        ("Min Load DELTA=10", 825, FILL_LIGHT_ORANGE,
         "Forcing cheapest transporter (DELTA) to ship adds 3.8%"),
        ("Block ALPHA→Coimbatore", 995, FILL_LIGHT_RED,
         "Losing cheapest route costs +25.2%"),
        ("Lock ALPHA→Chennai=25", 900, FILL_LIGHT_PURPLE,
         "Management override costs +13.2%"),
    ]

    optimal_cost = 795
    for i, (name, cost, fill, insight) in enumerate(scenarios):
        r = 4 + i
        _write_cell(ws5, r, 1, name, font=BOLD_FONT, fill=fill)
        _write_cell(ws5, r, 2, cost, fill=fill, num_fmt=NUM_FMT_COMMA)

        if cost == optimal_cost:
            _write_cell(ws5, r, 3, "Baseline", fill=fill,
                        align=Alignment(horizontal="center"))
            _write_cell(ws5, r, 4, 0, fill=fill, num_fmt=NUM_FMT_COMMA)
        else:
            pct = (cost - optimal_cost) / optimal_cost
            _write_cell(ws5, r, 3, pct,
                        fill=FILL_EXTRA_COST if pct > 0 else FILL_SAVINGS,
                        num_fmt='+0.0%' if pct > 0 else NUM_FMT_PCT)
            _write_cell(ws5, r, 4, cost - optimal_cost,
                        fill=FILL_EXTRA_COST if (cost - optimal_cost) > 0 else FILL_SAVINGS,
                        num_fmt='+#,##0' if (cost - optimal_cost) > 0 else NUM_FMT_COMMA)

        _write_cell(ws5, r, 5, insight, fill=fill,
                    align=Alignment(horizontal="left", wrap_text=True))

    _auto_width(ws5, min_width=14)
    ws5.column_dimensions["A"].width = 30
    ws5.column_dimensions["E"].width = 50

    # Save
    path = os.path.join(OUTPUT_DIR, "Comparison.xlsx")
    wb.save(path)
    print(f"  Comparison.xlsx - 5 sheets with formulas")


# ── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    total_supply = sum(sum(v) for v in REGIONAL_SUPPLY.values())
    total_demand = sum(DEMAND.values())

    print("Generating demo files...\n")
    create_cost_file()
    create_demand_file()
    create_supply_file()
    create_comparison_file()
    print(f"\n  Supply = {total_supply}  |  Demand = {total_demand}  |  Surplus = {total_supply - total_demand}")
    print(f"\n  Files saved to: {OUTPUT_DIR}")
