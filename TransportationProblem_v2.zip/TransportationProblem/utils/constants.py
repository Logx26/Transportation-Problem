INFINITY = 10**10

STATE_COLORS = {
    "RELEASE": "#90EE90",   # light green
    "LOCKED": "#FFA500",    # orange
    "BLOCKED": "#880808",   # dark red
    "DISABLED": "#808080",  # grey
}

STATE_TEXT_COLORS = {
    "RELEASE": "#000000",
    "LOCKED": "#FFFFFF",
    "BLOCKED": "#FFFFFF",
    "DISABLED": "#FFFFFF",
}
