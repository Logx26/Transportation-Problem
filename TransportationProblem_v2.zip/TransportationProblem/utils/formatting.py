import locale


def get_rupee_format(amount: float) -> str:
    try:
        locale.setlocale(locale.LC_ALL, 'en_IN.UTF-8')
        rupee_format = locale.currency(amount, grouping=True, symbol=False)
    except locale.Error:
        # Fallback for systems without en_IN locale
        rupee_format = f"{amount:,.2f}"
    return f"\u20b9{rupee_format}"
