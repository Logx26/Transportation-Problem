import streamlit as st

from ui.state import restore_allocation
from utils.formatting import get_rupee_format


def render_history_panel():
    """Render the allocation history panel in the sidebar."""
    history = st.session_state.allocation_history
    carrier = st.session_state.carrier_number
    lp_optimal = st.session_state.lp_optimal_cost

    st.sidebar.markdown("## Allocation History")

    if not history:
        st.sidebar.caption("No allocations yet.")
        return

    # Find lowest allocation cost entry
    lowest_cost = min(h[1] for h in history)

    for i, entry in enumerate(history):
        allocation_copy, cost, carrier_str = entry
        display_carrier = int(carrier_str) if carrier_str else carrier
        display_cost = cost * display_carrier

        iter_num = i + 1
        cost_str = get_rupee_format(round(display_cost, 2))
        is_cheapest = cost == lowest_cost

        # Δ vs Optimal
        if lp_optimal > 0:
            delta_pct = (cost - lp_optimal) / lp_optimal * 100
            delta_str = f"{'+' if delta_pct >= 0 else ''}{round(delta_pct, 1)}% vs Opt"
        else:
            delta_str = ""

        label = f"Iter {iter_num} \u2014 {cost_str}"
        if delta_str:
            label += f"  ({delta_str})"
        if is_cheapest:
            label = f"\u2605 {label}  [Best]"

        if st.sidebar.button(
            label,
            key=f"history_btn_{i}",
            use_container_width=True,
            type="primary" if is_cheapest else "secondary",
        ):
            restore_allocation(entry)
            st.rerun()

    # Current allocation cost vs Optimal
    if lp_optimal > 0:
        current_cost = st.session_state.optimal_cost
        diff_pct = (current_cost - lp_optimal) / lp_optimal * 100
        st.sidebar.markdown("---")
        st.sidebar.metric(
            label="Current vs Optimal",
            value=get_rupee_format(round(current_cost * carrier, 2)),
            delta=f"{'+' if diff_pct >= 0 else ''}{round(diff_pct, 1)}%",
            delta_color="inverse" if diff_pct > 0 else "normal",
        )
