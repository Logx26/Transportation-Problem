import altair as alt
import pandas as pd
import streamlit as st

from services.export_service import generate_export, get_export_filename
from solver.lp_solver import solve_lp
from ui.components.allocation_matrix import render_allocation_matrix
from ui.components.history_panel import render_history_panel
from ui.state import build_initial_allocation, get_allocation_copy
from utils.formatting import get_rupee_format


def render_allocation_page():
    # Sidebar: history panel
    render_history_panel()

    st.markdown("""
    <div style="margin-bottom:1.2rem;">
        <h1 style="margin:0; font-size:1.5rem; color:#1e293b; font-weight:700;">
            Allocation Results
        </h1>
        <p style="margin:4px 0 0; color:#64748b; font-size:13px;">
            Review the optimised allocation, adjust constraints, and re-run the solver.
        </p>
    </div>
    """, unsafe_allow_html=True)

    # Run solver on first entry (no history yet)
    if not st.session_state.allocation_history:
        _run_solver(first_entry=True)
        st.rerun()  # Force clean render so chart and costs display immediately

    if st.session_state.optimal_cost == 0.0 and not st.session_state.allocation_history:
        st.error("Infeasible solution. Please go back and adjust supply/demand or constraints.")
        if st.button("<- Back to Setup"):
            st.session_state.page = "setup"
            st.rerun()
        return

    # KPI + iteration chart section
    _render_cost_section()

    if st.session_state.get("last_solve_infeasible"):
        st.error(
            "Allocation not possible with the current constraints. "
            "The locked and blocked routes conflict with supply/demand requirements. "
            "Please relax some constraints and try Re-Allocate again."
        )

    st.markdown("---")

    # Allocation matrix
    render_allocation_matrix()

    st.markdown("---")

    # Action buttons
    _render_action_buttons()


def _run_solver(first_entry: bool = False):
    """Run the LP solver and store results in session state.

    On first_entry: runs two LP solves — super optimal (no min_load) and
    optimal (with min_load) — then stores both as fixed references.
    On subsequent calls: runs one LP solve with current locks/blocks.
    """
    supply = st.session_state.supply
    demand = st.session_state.demand
    cost_matrix = st.session_state.cost_matrix
    allocation = st.session_state.allocation
    min_load = st.session_state.min_load
    carrier = st.session_state.carrier_number

    with st.spinner("Solving transportation problem..."):
        if first_entry:
            # ── Super Optimal: unconstrained LP (no min_load) ─────────────────
            alloc_super = build_initial_allocation(demand, supply, cost_matrix)
            super_alloc, super_cost, _ = solve_lp(
                supply=supply,
                demand=demand,
                cost_matrix=cost_matrix,
                allocation=alloc_super,
                min_load={t: 0 for t in supply},
                regional_supply=st.session_state.regional_supply,
                destination_region=st.session_state.destination_region,
            )
            st.session_state.super_optimal_cost = super_cost
            st.session_state.super_optimal_allocation = get_allocation_copy(super_alloc)

            # ── Optimal: LP with min_load ─────────────────────────────────────
            updated_alloc, alloc_cost, status = solve_lp(
                supply=supply,
                demand=demand,
                cost_matrix=cost_matrix,
                allocation=allocation,
                min_load=min_load,
                regional_supply=st.session_state.regional_supply,
                destination_region=st.session_state.destination_region,
            )
            st.session_state.lp_optimal_cost = alloc_cost

        else:
            # ── Re-Allocate: LP with min_load + current locks/blocks ──────────
            updated_alloc, alloc_cost, status = solve_lp(
                supply=supply,
                demand=demand,
                cost_matrix=cost_matrix,
                allocation=allocation,
                min_load=min_load,
                regional_supply=st.session_state.regional_supply,
                destination_region=st.session_state.destination_region,
            )

    if status == "infeasible":
        st.session_state.last_solve_infeasible = True
        # Keep previous optimal_cost and history — do not overwrite with 0
        return

    st.session_state.last_solve_infeasible = False
    st.session_state.allocation = updated_alloc
    st.session_state.optimal_cost = alloc_cost
    st.session_state.allocation_changed = False

    # Record KPI for this iteration (raw per-carrier costs, multiplied at display time)
    st.session_state.iteration_kpi.append({
        "iter": len(st.session_state.iteration_kpi) + 1,
        "super_optimal": st.session_state.super_optimal_cost,
        "optimal": st.session_state.lp_optimal_cost,
        "allocation_cost": alloc_cost,
    })

    # Store in history
    allocation_snapshot = get_allocation_copy(updated_alloc)
    st.session_state.allocation_history.append(
        (allocation_snapshot, alloc_cost, str(carrier))
    )


def _render_cost_section():
    carrier = st.number_input(
        "Number of Carriers",
        min_value=1,
        max_value=1000,
        value=st.session_state.carrier_number,
        step=1,
        key="carrier_input",
    )
    if carrier != st.session_state.carrier_number:
        st.session_state.carrier_number = carrier

    super_cost = st.session_state.super_optimal_cost * carrier
    opt_cost = st.session_state.lp_optimal_cost * carrier
    alloc_cost = st.session_state.optimal_cost * carrier

    # ── Fixed reference KPIs ──────────────────────────────────────────────────
    col1, col2 = st.columns(2)
    with col1:
        st.metric(
            label="Super Optimal Cost",
            value=get_rupee_format(round(super_cost, 2)),
        )
    with col2:
        st.metric(
            label="Optimal Cost",
            value=get_rupee_format(round(opt_cost, 2)),
        )
    st.caption(
        "Super Optimal = unconstrained LP (no minimum allocation)  \u00a0|\u00a0  "
        "Optimal = LP with minimum allocation constraints"
    )

    # ── Current allocation cost ───────────────────────────────────────────────
    delta_pct = (
        (alloc_cost - opt_cost) / opt_cost * 100 if opt_cost > 0 else 0.0
    )
    delta_str = f"{'+' if delta_pct >= 0 else ''}{round(delta_pct, 1)}% vs Optimal"
    st.metric(
        label="Allocation Cost",
        value=get_rupee_format(round(alloc_cost, 2)),
        delta=delta_str,
        delta_color="inverse" if delta_pct > 0 else "normal",
    )

    # ── KPI iteration table ───────────────────────────────────────────────────
    kpi_list = st.session_state.iteration_kpi
    if kpi_list:
        st.markdown("#### Iteration Summary")
        rows = []
        for row in kpi_list:
            s = row["super_optimal"] * carrier
            o = row["optimal"] * carrier
            a = row["allocation_cost"] * carrier
            pct = (a - o) / o * 100 if o > 0 else 0.0
            rows.append({
                "Iteration": row["iter"],
                "Super Optimal": get_rupee_format(round(s, 2)),
                "Optimal": get_rupee_format(round(o, 2)),
                "Allocation Cost": get_rupee_format(round(a, 2)),
                "\u0394 vs Optimal": f"{'+' if pct >= 0 else ''}{round(pct, 1)}%",
            })
        st.dataframe(
            pd.DataFrame(rows).set_index("Iteration"),
            use_container_width=True,
        )

        # ── Bar chart: Super Optimal (blue) | Optimal (green) | Allocation N (amber)
        # Labels: Iter 1 → "Optimal", Iter 2 → "Allocation 1", Iter 3 → "Allocation 2", ...
        chart_rows = [
            {"Label": "Super Optimal", "Cost": round(st.session_state.super_optimal_cost * carrier, 2), "c": "super"},
        ]
        for idx, row in enumerate(kpi_list):
            if idx == 0:
                label, cgroup = "Optimal", "optimal"
            else:
                label, cgroup = f"Allocation {idx}", "allocation"
            chart_rows.append({
                "Label": label,
                "Cost": round(row["allocation_cost"] * carrier, 2),
                "c": cgroup,
            })
        label_order = [r["Label"] for r in chart_rows]
        costs = [r["Cost"] for r in chart_rows]
        y_max = max(costs)
        y_pad = y_max * 0.15 if y_max > 0 else 1
        chart = (
            alt.Chart(pd.DataFrame(chart_rows))
            .mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3)
            .encode(
                x=alt.X("Label:N", sort=label_order, title=None, axis=alt.Axis(labelAngle=0)),
                y=alt.Y(
                    "Cost:Q",
                    title="Cost (₹)",
                    scale=alt.Scale(domain=[0, y_max + y_pad]),
                ),
                color=alt.Color(
                    "c:N",
                    scale=alt.Scale(
                        domain=["super", "optimal", "allocation"],
                        range=["#5470c6", "#91cc75", "#fac858"],
                    ),
                    legend=None,
                ),
                tooltip=[
                    alt.Tooltip("Label:N", title=""),
                    alt.Tooltip("Cost:Q", title="Cost (₹)", format=",.0f"),
                ],
            )
        )
        text_layer = chart.mark_text(
            align="center", baseline="bottom", dy=-4, fontSize=11, fontWeight="bold"
        ).encode(
            text=alt.Text("Cost:Q", format=",.0f"),
            color=alt.value("#333333"),
        )
        st.altair_chart(chart + text_layer, use_container_width=True)


def _render_action_buttons():
    col_back, col_realloc, col_export = st.columns([1, 1, 2])

    with col_back:
        if st.button("<- Back", use_container_width=True):
            st.session_state.page = "setup"
            st.rerun()

    with col_realloc:
        allocation_changed = st.session_state.allocation_changed
        if st.button(
            "Re-Allocate",
            disabled=not allocation_changed,
            use_container_width=True,
            type="primary" if allocation_changed else "secondary",
        ):
            _run_solver(first_entry=False)
            st.rerun()

    with col_export:
        if st.session_state.allocation_history:
            try:
                export_bytes = generate_export(
                    supply=st.session_state.supply,
                    demand=st.session_state.demand,
                    allocation=st.session_state.allocation,
                    cost_matrix=st.session_state.cost_matrix,
                    min_load=st.session_state.min_load,
                    super_optimal_allocation=st.session_state.super_optimal_allocation,
                    super_optimal_cost=st.session_state.super_optimal_cost,
                    optimal_cost=st.session_state.optimal_cost,
                    carrier_number=st.session_state.carrier_number,
                    allocation_history=st.session_state.allocation_history,
                )
                st.download_button(
                    label="Export to Excel",
                    data=export_bytes,
                    file_name=get_export_filename(),
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                    type="primary",
                )
            except Exception as e:
                st.error(f"Export failed: {e}")
        else:
            st.button(
                "Export to Excel",
                disabled=True,
                use_container_width=True,
                help="Solve first.",
            )
