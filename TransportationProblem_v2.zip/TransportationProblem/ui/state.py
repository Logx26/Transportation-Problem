import streamlit as st

from models.enums import AllocationState


def init_session_state():
    """Initialize all session state keys with defaults if not already set."""
    defaults = {
        # Page navigation
        "page": "setup",
        # Staged file bytes (set when user selects files, before Load Files click)
        "cost_file_bytes_staged": None,
        "demand_file_bytes_staged": None,
        "supply_file_bytes_staged": None,
        # Raw file bytes (set after Load Files is clicked)
        "cost_file_bytes": None,
        "demand_file_bytes": None,
        "supply_file_bytes": None,
        # Stable DataFrames stored after Load Files
        "supply_df": None,         # pd.DataFrame | None — stable editable supply+min_load table
        "demand_df": None,         # pd.DataFrame | None — stable read-only demand table
        # Loaded data from files
        "transporters": [],        # list[Category]
        "destinations": [],        # list[Category]
        "region_map": {},          # {region: {"transporter": set, "destination": set}}
        "cost_matrix": {},         # {transporter: {destination: cost}}
        "destination_region": {},  # {destination: region}
        # User-configured values
        "supply": {},              # {transporter: int}
        "demand": {},              # {destination: int}
        "min_load": {},            # {transporter: int}
        "regional_supply": {},     # {transporter: {"North": n, "South": s, ...}}
        # Region filter
        "region_filter": "All",
        # Allocation state
        "allocation": {},          # {city: {tpt: {"value": int, "state": AllocationState}}}
        "allocation_history": [],  # list of (allocation_copy, allocation_cost, carrier_str)
        "optimal_cost": 0.0,       # most recent LP allocation cost (per-carrier, not multiplied)
        "lp_optimal_cost": 0.0,    # fixed LP optimal with min_load (set once on first entry)
        "super_optimal_cost": 0.0, # fixed LP optimal without min_load (set once on first entry)
        "super_optimal_allocation": {},  # allocation snapshot from super-optimal solve
        "iteration_kpi": [],       # list of {"iter": N, "super_optimal": X, "optimal": Y, "allocation_cost": Z}
        "carrier_number": 1,
        # UI helpers
        "allocation_changed": False,
        "last_solve_infeasible": False,
        # Selected route for state control
        "sel_dest": None,
        "sel_tpt": None,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val


def get_allocation_copy(allocation: dict) -> dict:
    """Deep-copy allocation dict for storing in history."""
    copy = {}
    for city, tpt_map in allocation.items():
        copy[city] = {}
        for tpt, data in tpt_map.items():
            copy[city][tpt] = {
                "value": data["value"],
                "state": data["state"],
            }
    return copy


def restore_allocation(history_entry: tuple):
    """Restore allocation from a history entry tuple."""
    allocation_copy, cost, carrier_num = history_entry
    st.session_state.allocation = get_allocation_copy(allocation_copy)
    st.session_state.optimal_cost = cost
    st.session_state.carrier_number = int(carrier_num) if carrier_num else 1
    st.session_state.allocation_changed = False
    st.session_state.sel_dest = None
    st.session_state.sel_tpt = None


def build_initial_allocation(demand: dict, supply: dict, cost_matrix: dict) -> dict:
    """Build a fresh allocation dict with all states set to RELEASE (or DISABLED for infinite cost)."""
    from utils.constants import INFINITY

    allocation = {}
    for city in demand.keys():
        allocation[city] = {}
        for tpt in supply.keys():
            cost = cost_matrix.get(tpt, {}).get(city, INFINITY)
            state = AllocationState.DISABLED if cost == INFINITY else AllocationState.RELEASE
            allocation[city][tpt] = {"value": 0, "state": state}
    return allocation
