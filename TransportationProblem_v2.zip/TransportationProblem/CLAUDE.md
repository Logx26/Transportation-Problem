# Transport Allocator

## Overview
Streamlit-based web app that solves transportation allocation problems using Mixed-Integer Linear Programming (PuLP). Users upload Cost/Demand/Supply Excel files, the solver computes optimal allocations minimizing total cost, and users can interactively lock/block/edit routes and re-solve.

## Tech Stack
- **Framework:** Streamlit 1.35+ (Python web UI)
- **Solver:** PuLP 2.7+ (MILP with CBC backend)
- **Data:** Pandas, DuckDB (Excel loading via spatial extension)
- **Grid:** streamlit-aggrid (AG Grid for interactive matrix)
- **Excel I/O:** openpyxl (read), xlsxwriter (write)
- **Python:** 3.13+

## Running
```bash
streamlit run app.py
```

## Project Structure
```
app.py                              # Entry point, page routing
ui/
  state.py                          # Session state init & helpers
  pages/
    setup_page.py                   # File upload, region filter, selection
    allocation_page.py              # Solver execution, cost display, controls
  components/
    allocation_matrix.py            # AG Grid matrix with JS cell styling
    history_panel.py                # Sidebar history + restore
models/
  enums.py                          # AllocationState: RELEASE|BLOCKED|LOCKED|DISABLED
  data_models.py                    # Category dataclass
services/
  data_loader.py                    # load_cost_file, load_demand_file, load_supply_file
  export_service.py                 # Multi-sheet Excel export
solver/
  lp_solver.py                      # solve_lp() - PuLP MILP core
  tta_solver.py                     # Greedy baseline (TTA) for cost comparison
utils/
  constants.py                      # INFINITY=10^10, STATE_COLORS
  formatting.py                     # Rupee currency formatting
input_files/                        # Sample Cost/Demand/Supply .xlsx files
transport_allocator.py              # Legacy PyQt5 app (archived, unused)
```

## Key Data Structures (Session State)
- `allocation`: `{destination: {transporter: {"value": int, "state": AllocationState}}}`
- `cost_matrix`: `{transporter: {destination: cost}}`
- `supply/demand`: `{name: qty}`
- `min_load`: `{transporter: min_qty}`
- `regional_supply`: `{transporter: {"North": n, "South": s, ...}}`
- `allocation_history`: list of `(allocation_copy, cost, carrier_count)` tuples

## Solver (lp_solver.py)
- **Objective:** Minimize Σ(allocation × cost) across all routes
- **Constraints:** supply equality, demand satisfaction, min_load, regional caps, dummy destination for surplus
- **State-based bounds:** RELEASE→free, BLOCKED→0, LOCKED→fixed, DISABLED→0
- **Returns:** (updated_allocation, optimal_cost, "optimal"|"infeasible")

## AllocationState Enum
| State    | Value | Color        | Meaning                    |
|----------|-------|--------------|----------------------------|
| RELEASE  | 1     | Green        | Solver-controlled          |
| BLOCKED  | 2     | Red          | Forced to 0                |
| LOCKED   | 3     | Yellow/Orange| Fixed at user's value       |
| DISABLED | 4     | Grey         | No route (infinite cost)   |

## App Flow
1. **Setup Page:** Upload files → select region/destinations/transporters → edit min_load → Allocate
2. **First Solve:** super_optimal (no min_load) + optimal (with min_load) as fixed baselines
3. **Allocation Page:** View matrix → lock/block/edit cells → Re-Allocate → history tracks iterations
4. **Export:** Multi-sheet Excel with allocation matrix, entry list, cost analysis

## Important Regions for Updates
- **solver/lp_solver.py** - Core optimization logic, constraint formulation
- **ui/pages/allocation_page.py** - Solver invocation, cost visualization (Altair bar chart), Re-Allocate flow
- **ui/components/allocation_matrix.py** - AG Grid rendering, cell state management, value change detection
- **ui/state.py** - Session state schema, build_initial_allocation(), restore_allocation()
- **services/data_loader.py** - File parsing, data normalization
- **services/export_service.py** - Excel export generation
