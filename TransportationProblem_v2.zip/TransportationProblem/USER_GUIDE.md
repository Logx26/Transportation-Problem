# Transport Allocator — User Guide

---

## Getting Started

**Install dependencies** (first time only):
```bash
cd l:\TransportationProblem
venv\Scripts\pip install -r requirements.txt
```

**Launch the app:**
```bash
venv\Scripts\streamlit run app.py
```
The app opens automatically at `http://localhost:8501` in your browser.

---

## Page 1 — Setup

This is where you configure the problem before solving.

### Step 1 — Upload Files

Three file uploaders appear at the top. Upload them **in order**:

| File | What It Contains | Mock File |
|---|---|---|
| **Cost File** | Transporter → Destination routes + costs | `input_files/Cost File.xlsx` |
| **Load Sheet** | Vehicle bay assignments (used to compute demand) | `input_files/Load Sheet.xlsx` |
| **Entry Sheet** | Transporter supply quantities per period | `input_files/Entry Sheet.xlsx` |

> The Cost File must be uploaded first — the other two files use it to match transporter and destination names.

After uploading, the app auto-populates:
- Transporters and destinations from the Cost File
- Demand values from the Load Sheet
- Supply values from the Entry Sheet

### Step 2 — Filter by Region *(optional)*

Use the **Region Filter** dropdown (`All`, `North`, `South`, etc.) to narrow the list of transporters and destinations shown. This is useful when operating in a specific zone.

### Step 3 — Select Transporters and Destinations

Two **multiselect** dropdowns let you choose which transporters and destinations to include in this run. Items auto-select when loaded from the Load/Entry sheets.

### Step 4 — Review and Edit Supply / Demand

Two editable tables appear below the multiselects:

- **Destinations table** — edit demand quantities per city
- **Transporters table** — edit supply quantities and minimum load per transporter

The **Balance** metric (Supply − Demand) is shown live. A positive balance is normal — the solver handles the surplus with a dummy destination at zero cost.

### Step 5 — Click "Allocate"

Validates inputs and runs the MILP solver. The page switches to the Allocation view automatically.

---

## Page 2 — Allocation

This is where you view results, adjust constraints, and export.

### The Allocation Matrix

A color-coded grid shows the optimal allocation:

| Color | Meaning |
|---|---|
| **Green** | RELEASE — solver assigned this route; value is optimal |
| **Orange** | LOCKED — you fixed this value; solver will not change it |
| **Dark Red** | BLOCKED — route is prohibited; solver assigns 0 |
| **Grey** | DISABLED — route has no available cost; automatically excluded |

Each cell shows how many units are allocated from a transporter to a destination.

### Route State Controls

Click **"Route State Controls"** to expand the control panel:

1. Pick a **Destination** and **Transporter** from the dropdowns
2. Choose the new **State**: `RELEASE`, `LOCKED`, or `BLOCKED`
3. Click **Apply**

> **LOCKED** — fixes the current allocation value. The solver will not change it in future re-solves.
> **BLOCKED** — sets the allocation to 0 and excludes the route entirely.
> **RELEASE** — returns the route to solver control.

After changing states, click **Re-Allocate** to re-run the solver with the new constraints.

### Cost Summary

Three metric cards show:

- **Optimal Allocation Cost** — LP solver result × number of carriers
- **TTA Baseline Cost** — greedy benchmark (cheapest transporter first, no optimization)
- **Cost Savings vs TTA** — money saved by using LP optimization over the naive approach

A **bar chart** visualizes the comparison side by side.

### Number of Carriers

The `Number of Carriers` input multiplies the per-unit cost to get the total cost for your fleet. Default is 8. Change it to see the total cost update instantly.

### Allocation History (Sidebar)

Every time you solve, the result is saved to the sidebar history. Each entry shows the total cost for that run.

- A ★ **star** marks the cheapest result found so far
- Click any history entry to **restore** that allocation to the main view
- The **"Difference from Best"** metric shows how much more the current selection costs vs the best run

### Re-Allocate vs Export

| Button | When Active | Action |
|---|---|---|
| **Re-Allocate** | After any state/value change | Re-runs solver with current constraints |
| **Export to Excel** | After a fresh solve (no pending changes) | Downloads multi-sheet `.xlsx` file |

> If you change route states or values, Re-Allocate first — Export is disabled until you do.

### Back

Returns to the Setup page. Your supply/demand/file configuration is preserved.

---

## Exported Excel File

The download contains 4 sheets:

| Sheet | Contents |
|---|---|
| **Supply and Demand** | Final supply, demand, and minimum load values |
| **Allocation Entry** | Flat list: Destination, Transporter, Load quantity |
| **Allocation Matrix** | 2D grid (destinations × transporters) + cost matrix below + TTA comparison |
| **Rejected and Locked Allocation** | All BLOCKED/LOCKED routes + cost overrun analysis vs TTA savings |

---

## Typical Workflow

```
Upload Cost File → Upload Load Sheet → Upload Entry Sheet
        ↓
Review / adjust supply & demand
        ↓
Click Allocate → View optimal matrix
        ↓
Lock specific routes (e.g. committed contracts)
Block unavailable routes
        ↓
Re-Allocate → Compare cost in history
        ↓
Repeat until satisfied → Export to Excel
```

---

## Input File Formats

### Cost File (.xlsx)

| Column | Description |
|---|---|
| `Transporter` | Name of the transporter |
| `Destination` | Name of the destination city |
| `Region` | Region category (e.g. South, North) |
| `Medium Car / INR` | Cost per unit for this route |

Each row is one valid transporter → destination route. Missing combinations are treated as unavailable (DISABLED).

### Load Sheet (.xlsx)

| Column | Description |
|---|---|
| `destination` | Destination city name |
| `bay` | Bay identifier (e.g. BAY-01) |

Each row is one vehicle assignment. Demand per destination is derived by finding the most common destination per bay, then counting how many bays each destination wins.

### Entry Sheet (.xlsx)

- Row 1–2: Title/subtitle rows (ignored by the app)
- Row 3: Header row — first column must be **blank**, followed by any columns, then four columns all named `Total`
- Row 4+: Transporter name in column A, supply quantities in the four `Total` columns

The app sums all four `Total` columns to get total supply per transporter.

---

## Mock Files

Sample files for testing are in the `input_files/` folder:

| File | Transporters | Destinations | Notes |
|---|---|---|---|
| `Cost File.xlsx` | 5 | 5 | 4 routes intentionally disabled |
| `Load Sheet.xlsx` | — | 5 | 300 vehicle entries, 10 bays |
| `Entry Sheet.xlsx` | 5 | — | Supply split across 4 weekly periods |

To regenerate or customise the mock files, edit and run:
```bash
venv\Scripts\python input_files/create_mock_files.py
```
