from dataclasses import dataclass, field


@dataclass
class Category:
    value: str
    is_checked: bool = False

    def __repr__(self):
        return f"Category(value={self.value!r}, is_checked={self.is_checked})"
