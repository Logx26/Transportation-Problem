from enum import Enum


class AllocationState(Enum):
    RELEASE = 1
    BLOCKED = 2
    LOCKED = 3
    DISABLED = 4
